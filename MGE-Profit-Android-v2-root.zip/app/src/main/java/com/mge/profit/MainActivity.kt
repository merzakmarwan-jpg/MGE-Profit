package com.mge.profit

import android.app.Activity
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.content.FileProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.card.MaterialCardView
import java.io.File
import java.io.InputStreamReader
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var repo: Repository
    private lateinit var content: LinearLayout
    private var selectionMode = false
    private val selected = linkedSetOf<String>()
    private var filterType = 0
    private var filterDate = ""
    private var filterCommercial = ""
    private val pendingImports = mutableListOf<Uri>()
    private var pendingIndex = 0
    private var editingInvoice: Invoice? = null
    private var editingDirty = false
    private var editingSaveAction: (() -> Boolean)? = null
    private val EXPORT_DATA = 810
    private val IMPORT_DATA = 811

    private val blue = Color.rgb(30, 112, 205)
    private val blueDark = Color.rgb(20, 82, 158)
    private val blueLight = Color.rgb(235, 244, 255)
    private val purple = Color.rgb(93, 67, 172)
    private val green = Color.rgb(29, 145, 83)
    private val orange = Color.rgb(220, 137, 17)
    private val red = Color.rgb(200, 67, 67)
    private val ink = Color.rgb(35, 38, 48)
    private val muted = Color.rgb(105, 108, 118)
    private val bg = Color.rgb(247, 248, 252)
    private val border = Color.rgb(225, 228, 235)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        repo = Repository(this)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (editingInvoice != null) {
                    guardedNavigate { invoices() }
                } else {
                    finish()
                }
            }
        })
        dashboard()
    }

    private fun tv(value: String, size: Float, bold: Boolean = false, color: Int = ink): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            includeFontPadding = true
            if (bold) typeface = Typeface.create(typeface, Typeface.BOLD)
        }

    private fun rounded(color: Int, radius: Int = 16, stroke: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }

    private fun page(title: String, subtitle: String = "", showNav: Boolean = true): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(blue)
        }

        val menu = TextView(this).apply {
            text = "☰"
            textSize = 31f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setOnClickListener { drawer() }
        }
        header.addView(menu, LinearLayout.LayoutParams(dp(52), dp(58)))

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        titleBox.addView(tv(title, 25f, true, Color.WHITE).apply { gravity = Gravity.CENTER })
        if (subtitle.isNotBlank()) titleBox.addView(tv(subtitle, 12.5f, false, Color.WHITE).apply { alpha = 0.88f; gravity = Gravity.CENTER })
        header.addView(titleBox, LinearLayout.LayoutParams(0, dp(58), 1f))

        val logo = ImageView(this).apply {
            setImageResource(com.mge.profit.R.drawable.mge_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.WHITE, 10)
            setPadding(dp(2), dp(2), dp(2), dp(2))
            contentDescription = "MGE Profit"
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(52), dp(52)))
        root.addView(header)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), if (showNav) dp(12) else dp(18))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (showNav) root.addView(bottomNav())
        setContentView(root)
        return content
    }

    private fun guardedNavigate(action: () -> Unit) {
        if (editingInvoice == null || !editingDirty) {
            action()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("حفظ الفاتورة؟")
            .setMessage("لديك تعديلات غير محفوظة على الفاتورة #${editingInvoice?.number}. ماذا تريد أن تفعل؟")
            .setPositiveButton("حفظ الفاتورة") { _, _ ->
                val saved = editingSaveAction?.invoke() ?: false
                if (saved) action()
            }
            .setNegativeButton("إلغاء", null)
            .setNeutralButton("غلق بدون حفظ") { _, _ ->
                editingInvoice = null
                editingDirty = false
                editingSaveAction = null
                action()
            }
            .show()
    }

    private fun bottomNav(): View {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
            setPadding(dp(4), dp(5), dp(4), dp(5))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val current = when {
            titleOfPage() == "الفواتير" -> 1
            titleOfPage() == "المنتجات" -> 2
            titleOfPage() == "التقارير" -> 3
            titleOfPage() == "الإعدادات" -> 4
            else -> 0
        }
        data class NavItem(val icon: String, val label: String, val index: Int, val action: () -> Unit)
        val items = listOf(
            NavItem("⌂", "الرئيسية", 0) { guardedNavigate { dashboard() } },
            NavItem("▤", "الفواتير", 1) { guardedNavigate { invoices() } },
            NavItem("▦", "المنتجات", 2) { guardedNavigate { products() } },
            NavItem("▥", "التقارير", 3) { guardedNavigate { reports() } },
            NavItem("⚙", "الإعدادات", 4) { guardedNavigate { settings() } }
        )
        items.forEach { item ->
            val selectedBg = if (current == item.index) blueLight else Color.TRANSPARENT
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(3), dp(3), dp(3))
                background = rounded(selectedBg, 14)
                setOnClickListener { item.action() }
            }
            box.addView(TextView(this).apply {
                text = item.icon
                textSize = 33f
                gravity = Gravity.CENTER
                setTextColor(if (current == item.index) blue else Color.rgb(90, 99, 112))
            }, LinearLayout.LayoutParams(-1, dp(32)))
            box.addView(TextView(this).apply {
                text = item.label
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(if (current == item.index) blue else Color.rgb(90, 99, 112))
            }, LinearLayout.LayoutParams(-1, dp(25)))
            nav.addView(box, LinearLayout.LayoutParams(0, dp(78), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        return nav
    }

    private fun titleOfPage(): String = currentTitle
    private var currentTitle = "الرئيسية"

    private fun card(view: View, radius: Int = 16, marginTop: Int = 6, marginBottom: Int = 6): MaterialCardView =
        MaterialCardView(this).apply {
            this.radius = dp(radius).toFloat()
            cardElevation = dp(1).toFloat()
            strokeWidth = dp(1)
            strokeColor = border
            setCardBackgroundColor(Color.WHITE)
            addView(view)
            layoutParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, dp(marginTop), 0, dp(marginBottom))
            }
        }

    private fun button(label: String, action: () -> Unit, filled: Boolean = true, height: Int = 52): TextView =
        TextView(this).apply {
            text = label
            textSize = 15f
            gravity = Gravity.CENTER
            typeface = Typeface.create(typeface, Typeface.BOLD)
            setTextColor(if (filled) Color.WHITE else blue)
            background = rounded(if (filled) blue else Color.WHITE, 14, if (filled) blue else Color.rgb(214, 221, 231))
            setOnClickListener { action() }
            setPadding(dp(8), dp(5), dp(8), dp(5))
            layoutParams = LinearLayout.LayoutParams(-1, dp(height))
        }

    private fun section(title: String, subtitle: String = "") {
        content.addView(tv(title, 20f, true).apply { setPadding(dp(4), dp(14), dp(4), dp(2)) })
        if (subtitle.isNotBlank()) content.addView(tv(subtitle, 13f, false, muted).apply { setPadding(dp(4), 0, dp(4), dp(7)) })
    }

    private fun drawer() {
        MaterialAlertDialogBuilder(this).setTitle("MGE Profit")
            .setItems(arrayOf("الرئيسية", "الفواتير", "المنتجات", "التقارير", "الإعدادات")) { _, which ->
                when (which) { 0 -> guardedNavigate { dashboard() }; 1 -> guardedNavigate { invoices() }; 2 -> guardedNavigate { products() }; 3 -> guardedNavigate { reports() }; 4 -> guardedNavigate { settings() } }
            }.show()
    }

    private fun dashboard() {
        currentTitle = "الرئيسية"
        val c = page("الرئيسية", "إدارة أرباح فواتير MGE")
        val inv = repo.invoices()
        val sales = inv.sumOf { it.productSales }
        val cost = inv.sumOf { it.purchaseCost }
        val partner = inv.sumOf { it.commercialProfit }
        val net = inv.sumOf { it.netProfit }

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        hero.addView(tv("MGE", 38f, true, blue).apply { gravity = Gravity.CENTER })
        hero.addView(tv("حساب أرباح الفواتير", 22f, true).apply { gravity = Gravity.CENTER })
        hero.addView(tv("الفواتير • المنتجات • الأرباح • الشركاء", 13f, false, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
        c.addView(card(hero, 18))

        val grid = GridLayout(this).apply { columnCount = 2; rowCount = 2 }
        quickTile(grid, "📄", "الفواتير", "إدارة واستدعاء الفواتير") { guardedNavigate { invoices() } }
        quickTile(grid, "📦", "المنتجات", "أسعار الشراء والتاريخ") { guardedNavigate { products() } }
        quickTile(grid, "📊", "التقارير", "الأرباح حسب المنتج والشريك") { guardedNavigate { reports() } }
        quickTile(grid, "⚙", "الإعدادات", "إعدادات التطبيق والبيانات") { guardedNavigate { settings() } }
        c.addView(grid)

        c.addView(button("＋  جلب فواتير PDF جديدة", { pickPdfs() }, true, 56).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, dp(10), 0, dp(6)) } })

        section("ملخص الأرباح")
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
        statRow(stats, "عدد الفواتير", inv.size.toString(), purple)
        statRow(stats, "إجمالي المبيعات", money(sales), green)
        statRow(stats, "تكلفة الشراء", money(cost), orange)
        statRow(stats, "أرباح الشركاء", money(partner), blue)
        statRow(stats, "صافي ربح MGE", money(net), if (net >= 0) green else red)
        c.addView(card(stats))

        section("آخر الفواتير")
        if (inv.isEmpty()) c.addView(emptyState("لا توجد فواتير بعد", "اضغط على جلب فواتير PDF للبدء"))
        else inv.take(5).forEach { invoiceCard(it, false) }
    }

    private fun quickTile(grid: GridLayout, icon: String, title: String, sub: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(18))
            background = rounded(Color.WHITE, 18, border)
            setOnClickListener { action() }
        }
        box.addView(tv(icon, 30f).apply { gravity = Gravity.CENTER; setTextColor(blue) }, LinearLayout.LayoutParams(-1, dp(42)))
        box.addView(tv(title, 19f, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(4)) })
        box.addView(tv(sub, 12.5f, false, muted).apply { gravity = Gravity.CENTER })
        grid.addView(box, GridLayout.LayoutParams().apply {
            width = 0; height = dp(170); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(4), dp(4), dp(4), dp(4))
        })
    }

    private fun statRow(parent: LinearLayout, label: String, value: String, color: Int) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        row.addView(tv(label, 15f, false, muted), LinearLayout.LayoutParams(0, dp(40), 1f))
        row.addView(tv(value, 18f, true, color), LinearLayout.LayoutParams(dp(190), dp(40)))
        parent.addView(row)
    }

    private fun emptyState(title: String, subtitle: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(28), dp(20), dp(28)) }
        box.addView(tv("○", 36f, true, muted).apply { gravity = Gravity.CENTER })
        box.addView(tv(title, 18f, true, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(4)) })
        box.addView(tv(subtitle, 13f, false, muted).apply { gravity = Gravity.CENTER })
        return card(box)
    }

    private fun invoices() {
        currentTitle = "الفواتير"
        val c = page("الفواتير", "إدارة واستدعاء فواتير MGE")

        val search = EditText(this).apply {
            hint = "🔎  ابحث برقم الفاتورة أو الزبون أو الهاتف أو التاريخ"
            textSize = 14f
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(Color.WHITE, 16, border)
        }
        c.addView(search, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, 0, 0, dp(8)) })

        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        filters.addView(button("⚙ الفلترة", { filterDialog() }, false, 50), LinearLayout.LayoutParams(0, dp(50), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        filters.addView(button(if (selectionMode) "✓ إلغاء التحديد" else "☑ تحديد", { toggleSelection() }, false, 50), LinearLayout.LayoutParams(0, dp(50), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        filters.addView(button("＋ جلب جديدة", { pickPdfs() }, true, 50), LinearLayout.LayoutParams(0, dp(50), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        c.addView(filters)

        if (selectionMode) {
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(3)) }
            actions.addView(button("تحديد الكل", { repo.invoices().forEach { selected.add(it.number) }; invoices() }, false, 48), LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            actions.addView(button("حذف", { confirmDeleteSelected() }, false, 48), LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            actions.addView(button("PDF الربح", { shareSelectedMargin() }, false, 48), LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            c.addView(actions)
        }

        val info = tv("", 13f, false, muted).apply { setPadding(dp(5), dp(10), dp(5), dp(5)) }
        c.addView(info)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(list)

        fun draw() {
            list.removeAllViews()
            val q = search.text.toString().trim().lowercase(Locale.getDefault())
            val data = filteredInvoices().filter { inv ->
                q.isBlank() || inv.number.contains(q, true) || inv.clientName.contains(q, true) || inv.commercial.contains(q, true) || inv.phone.contains(q, true) || inv.date.contains(q, true) || inv.city.contains(q, true) || inv.address.contains(q, true)
            }
            info.text = "${data.size} فاتورة ظاهرة"
            if (data.isEmpty()) list.addView(emptyState("لا توجد نتائج", "غيّر البحث أو الفلترة"))
            else data.forEach { invoiceCard(it, selectionMode, list) }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { draw() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        draw()
    }

    private fun filteredInvoices(): List<Invoice> = repo.invoices().filter { inv ->
        val typeOk = when (filterType) { 1 -> !inv.isCommercialInvoice; 2 -> inv.isCommercialInvoice; else -> true }
        val dateOk = filterDate.isBlank() || inv.date.contains(filterDate, true)
        val commOk = filterCommercial.isBlank() || inv.commercial.contains(filterCommercial, true)
        typeOk && dateOk && commOk
    }

    private fun copyField(label: String, value: String, copyValue: String = value): TextView {
        return tv(value, 13f, false, muted).apply {
            setPadding(0, dp(3), 0, dp(3))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val clean = copyValue.trim()
                if (clean.isBlank()) return@setOnClickListener
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText(label, clean))
                Toast.makeText(this@MainActivity, "تم نسخ $label", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun phoneCopyField(phone: String): TextView {
        return copyField("رقم الهاتف", "${phone}  📞", phone).apply {
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(Color.rgb(248, 249, 252), 12, border)
            layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, dp(5), 0, dp(3)) }
        }
    }

    private fun viewInvoice(invoice: Invoice) {
        editingInvoice = null
        editingDirty = false
        editingSaveAction = null
        currentTitle = "الفاتورة"
        val c = page("الفاتورة #${invoice.number}", "بيانات الفاتورة والأرباح")

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(15), dp(18), dp(15))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val clientBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        clientBox.addView(copyField("اسم الزبون", invoice.clientName.ifBlank { "بدون اسم الزبون" }).apply {
            textSize = 22f
            setTextColor(ink)
            typeface = Typeface.create(typeface, Typeface.BOLD)
        })
        if (invoice.phone.isNotBlank()) clientBox.addView(phoneCopyField(invoice.phone))
        if (invoice.city.isNotBlank()) clientBox.addView(copyField("المدينة", "📍 ${invoice.city}", invoice.city))
        if (invoice.address.isNotBlank()) clientBox.addView(copyField("العنوان", "🏠 ${invoice.address}", invoice.address))
        clientBox.addView(tv("📅 ${invoice.date}", 13f, false, muted).apply { setPadding(0, dp(4), 0, 0) })
        top.addView(clientBox, LinearLayout.LayoutParams(0, -2, 1f))

        val totalBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        totalBox.addView(tv("إجمالي الفاتورة", 12.5f, false, muted).apply { gravity = Gravity.CENTER })
        totalBox.addView(tv(money(invoice.total), 21f, true, blue).apply { gravity = Gravity.CENTER })
        totalBox.addView(tv("الشحن: ${money(invoice.shipping)}", 12f, false, muted).apply { gravity = Gravity.CENTER })
        if (invoice.actualShippingCost != invoice.shipping) {
            totalBox.addView(tv("فعلي: ${money(invoice.actualShippingCost)}", 12f, true, orange).apply { gravity = Gravity.CENTER })
        }
        top.addView(totalBox, LinearLayout.LayoutParams(dp(165), -2))
        head.addView(top)
        val partnerLine = if (invoice.isCommercialInvoice) {
            "🤝 Commercial: ${invoice.commercial}   •   ربح الشريك: ${money(invoice.effectivePartnerProfit)}"
        } else "👤 فاتورة مباشرة — لا يوجد شريك"
        head.addView(tv(partnerLine, 13.5f, true, if (invoice.isCommercialInvoice) purple else blue).apply {
            setPadding(0, dp(9), 0, 0)
            gravity = Gravity.CENTER
        })
        c.addView(card(head, 18))

        section("المنتجات")
        val productsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        invoice.items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(Color.WHITE, 14, border)
            }
            row.addView(tv(item.name, 15f, true).apply { gravity = Gravity.RIGHT; maxLines = 2 })
            row.addView(tv("الكمية: ${fmtQty(item.quantity)}   •   سعر البيع: ${money(item.saleUnitPrice)}   •   الإجمالي: ${money(item.saleTotal)}", 12.5f, false, muted).apply {
                gravity = Gravity.RIGHT; setPadding(0, dp(5), 0, 0)
            })
            row.addView(tv("سعر الشراء: ${money(item.purchasePriceAtSale)}   •   ربح MGE: ${money(item.netProfit)}", 12.5f, true, if (item.netProfit >= 0) green else red).apply {
                gravity = Gravity.RIGHT; setPadding(0, dp(4), 0, 0)
            })
            productsBox.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) })
        }
        c.addView(card(productsBox, 16, 4, 8))

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(236, 251, 242), 14, Color.rgb(190, 235, 208))
        }
        summary.addView(tv("تكلفة المنتجات: ${money(invoice.purchaseCost)}", 14f, true, orange).apply { gravity = Gravity.RIGHT })
        summary.addView(tv("هامش الربح: ${money(invoice.grossProfit)}", 15f, true, green).apply { gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, 0) })
        if (invoice.isCommercialInvoice) summary.addView(tv("ربح الشريك: ${money(invoice.effectivePartnerProfit)}", 14f, true, purple).apply { gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, 0) })
        summary.addView(tv("صافي الربح: ${money(invoice.netProfit)}", 17f, true, if (invoice.netProfit >= 0) green else red).apply { gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, 0) })
        c.addView(card(summary, 14, 4, 10))

        val editDelete = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        editDelete.addView(button("✎  تعديل الفاتورة", { editInvoice(invoice) }, true, 54), LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(0, dp(4), dp(4), dp(5)) })
        editDelete.addView(button("🗑  حذف", { confirmDelete(invoice) }, false, 54), LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(4), dp(4), 0, dp(5)) })
        c.addView(editDelete)
        c.addView(button("📄  مشاركة PDF الأصلي", { shareOriginal(invoice) }, false, 52).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, 0, 0, dp(6)) } })
        c.addView(button("📊  مشاركة PDF هامش الربح", { shareMargin(invoice) }, false, 52))
    }

    private fun shippingEditor(parent: LinearLayout, invoice: Invoice, onChanged: () -> Unit): EditText {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(Color.rgb(248, 249, 252), 14, border)
        }
        box.addView(tv("تكلفة الشحن الفعلية", 14f, true, orange).apply { gravity = Gravity.RIGHT })
        box.addView(tv("الشحن في الفاتورة: ${money(invoice.shipping)} — عدّل المبلغ الذي اقتطعته شركة الشحن فعليًا. الفرق يُخصم من هامش الربح وصافي الربح.", 12f, false, muted).apply {
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(7))
        })
        val field = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            textSize = 18f
            gravity = Gravity.CENTER
            setText(fmtMoneyNumber(invoice.actualShippingCost))
            setTextColor(ink)
            background = rounded(Color.WHITE, 12, orange)
            setPadding(dp(8), 0, dp(8), 0)
        }
        box.addView(field, LinearLayout.LayoutParams(-1, dp(52)))
        val difference = tv("", 13f, true, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0) }
        box.addView(difference)

        fun updateDifference() {
            val actual = field.text.toString().replace(",", ".").toDoubleOrNull() ?: invoice.shipping
            val diff = actual - invoice.shipping
            difference.text = when {
                diff > 0.0 -> "زيادة تكلفة الشحن: ${money(diff)} ← تُخصم من الربح"
                diff < 0.0 -> "وفر في الشحن: ${money(-diff)} ← يُضاف إلى الربح"
                else -> "لا يوجد فرق في تكلفة الشحن"
            }
            difference.setTextColor(if (diff > 0.0) red else if (diff < 0.0) green else muted)
        }
        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                invoice.actualShippingCost = s?.toString()?.replace(",", ".")?.toDoubleOrNull() ?: 0.0
                updateDifference()
                onChanged()
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        updateDifference()
        parent.addView(card(box, 14, 5, 5))
        return field
    }

    private fun invoiceCard(invoice: Invoice, selectable: Boolean, target: LinearLayout = content) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(13), dp(16), dp(13)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (selectable) top.addView(CheckBox(this).apply {
            isChecked = selected.contains(invoice.number)
            buttonTintList = android.content.res.ColorStateList.valueOf(blue)
            setOnCheckedChangeListener { _, checked -> if (checked) selected.add(invoice.number) else selected.remove(invoice.number) }
        }, LinearLayout.LayoutParams(dp(45), dp(45)))
        top.addView(tv("#${invoice.number}", 22f, true, blue), LinearLayout.LayoutParams(0, dp(45), 1f))
        top.addView(tv(money(invoice.netProfit), 17f, true, if (invoice.netProfit >= 0) green else red), LinearLayout.LayoutParams(dp(150), dp(45)))
        box.addView(top)
        box.addView(copyField("اسم الزبون", invoice.clientName.ifBlank { "بدون اسم الزبون" }).apply {
            textSize = 17f
            setTextColor(ink)
            typeface = Typeface.create(typeface, Typeface.BOLD)
        })
        if (invoice.phone.isNotBlank()) box.addView(phoneCopyField(invoice.phone))
        if (invoice.city.isNotBlank()) box.addView(copyField("المدينة", "📍 ${invoice.city}", invoice.city))
        if (invoice.address.isNotBlank()) box.addView(copyField("العنوان", "🏠 ${invoice.address}", invoice.address))
        box.addView(tv("📅 ${invoice.date}   •   ${if (invoice.isCommercialInvoice) "🤝 ${invoice.commercial}" else "مباشرة"}", 13f, false, muted).apply { setPadding(0, dp(2), 0, dp(2)) })
        box.addView(tv("المبيعات ${money(invoice.productSales)}   •   الشحن ${money(invoice.shipping)} / فعلي ${money(invoice.actualShippingCost)}   •   ${invoice.items.size} منتجات", 12.5f, false, muted))
        if (invoice.isCommercialInvoice) box.addView(tv("ربح الشريك: ${money(invoice.commercialProfit)}", 13f, true, blue))

        // إجراءات الفاتورة تظهر مباشرة داخل بطاقة الفاتورة، بدون فتح صفحة تفاصيل وسيطة.
        if (!selectionMode) {
            val actions1 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(2))
            }
            actions1.addView(button("✎  تعديل", { editInvoice(invoice) }, true, 46), LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            actions1.addView(button("🗑  حذف", { confirmDelete(invoice) }, false, 46), LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            box.addView(actions1)

            val actions2 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(2), 0, dp(2))
            }
            actions2.addView(button("📄  PDF الأصلي", { shareOriginal(invoice) }, false, 46), LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            actions2.addView(button("📊  PDF هامش الربح", { shareMargin(invoice) }, false, 46), LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            box.addView(actions2)
        } else {
            box.setOnClickListener {
                if (selected.contains(invoice.number)) selected.remove(invoice.number) else selected.add(invoice.number)
                invoices()
            }
        }
        target.addView(card(box))
    }

    private fun filterDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), 0) }
        val radio = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val all = RadioButton(this).apply { text = "كل الفواتير"; id = 1 }
        val admin = RadioButton(this).apply { text = "فواتير الأدمن / مباشرة"; id = 2 }
        val commercial = RadioButton(this).apply { text = "فواتير الشركاء / Commercial"; id = 3 }
        radio.addView(all); radio.addView(admin); radio.addView(commercial)
        radio.check(if (filterType == 1) 2 else if (filterType == 2) 3 else 1)
        val date = EditText(this).apply { hint = "التاريخ، مثال: 03/09/2026"; setText(filterDate); setSingleLine(true) }
        val comm = EditText(this).apply { hint = "اسم الشريك Commercial"; setText(filterCommercial); setSingleLine(true) }
        box.addView(tv("نوع الفاتورة", 15f, true, blue)); box.addView(radio); box.addView(date); box.addView(comm)
        MaterialAlertDialogBuilder(this).setTitle("فلترة الفواتير").setView(box)
            .setPositiveButton("تطبيق") { _, _ ->
                filterType = when (radio.checkedRadioButtonId) { 2 -> 1; 3 -> 2; else -> 0 }
                filterDate = date.text.toString().trim(); filterCommercial = comm.text.toString().trim(); invoices()
            }.setNegativeButton("إلغاء", null)
            .setNeutralButton("مسح الفلترة") { _, _ -> filterType = 0; filterDate = ""; filterCommercial = ""; invoices() }.show()
    }

    private fun toggleSelection() { selectionMode = !selectionMode; if (!selectionMode) selected.clear(); invoices() }

    private fun confirmDeleteSelected() {
        if (selected.isEmpty()) { Toast.makeText(this, "لم تحدد أي فاتورة", Toast.LENGTH_SHORT).show(); return }
        MaterialAlertDialogBuilder(this).setTitle("حذف الفواتير")
            .setMessage("سيتم حذف ${selected.size} فاتورة من التطبيق. هل أنت متأكد؟")
            .setPositiveButton("حذف") { _, _ -> repo.deleteInvoices(selected); selected.clear(); selectionMode = false; invoices() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun products() {
        currentTitle = "المنتجات"
        val c = page("المنتجات", "أسعار الشراء الحالية + سجل كل تغيير")
        val search = EditText(this).apply { hint = "🔎  ابحث باسم المنتج"; textSize = 14f; setSingleLine(true); setPadding(dp(16), 0, dp(16), 0); background = rounded(Color.WHITE, 16, border) }
        c.addView(search, LinearLayout.LayoutParams(-1, dp(56)))
        c.addView(button("＋  إضافة منتج / سعر شراء", { editProduct(null) }, true, 54).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(9), 0, dp(5)) } })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(list)
        fun draw() {
            list.removeAllViews(); val q = search.text.toString().trim().lowercase(Locale.getDefault())
            val data = repo.products().sortedBy { it.name.lowercase(Locale.getDefault()) }.filter { q.isBlank() || it.name.lowercase(Locale.getDefault()).contains(q) }
            if (data.isEmpty()) list.addView(emptyState("لا توجد منتجات", "أضف المنتجات وأسعار الشراء الخاصة بها"))
            data.forEach { p ->
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); setOnClickListener { productHistory(p.name) } }
                box.addView(tv(p.name, 17f, true))
                box.addView(tv("سعر الشراء الحالي", 12.5f, false, muted).apply { setPadding(0, dp(6), 0, 0) })
                box.addView(tv(money(p.currentPurchasePrice), 22f, true, blue))
                box.addView(tv("📋 سجل الأسعار: ${p.history.size}   •   اضغط لعرض السجل والتعديل", 12.5f, false, muted).apply { setPadding(0, dp(3), 0, 0) })
                list.addView(card(box))
            }
        }
        search.addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, d: Int)=Unit; override fun onTextChanged(s: CharSequence?,a:Int,b:Int,d:Int){draw()}; override fun afterTextChanged(s: Editable?)=Unit })
        draw()
    }

    private fun editProduct(existing: String?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), 0, dp(22), 0) }
        val name = EditText(this).apply { hint = "اسم المنتج"; setText(existing ?: ""); setSingleLine(true) }
        val price = EditText(this).apply { hint = "سعر الشراء للوحدة DH"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        repo.findProduct(existing ?: "")?.let { price.setText(it.currentPurchasePrice.toString()) }
        box.addView(name); box.addView(price)
        MaterialAlertDialogBuilder(this).setTitle(if (existing == null) "إضافة منتج" else "تعديل سعر الشراء").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim(); val p = price.text.toString().replace(",", ".").toDoubleOrNull()
                if (n.isBlank() || p == null) Toast.makeText(this, "أدخل الاسم والسعر بشكل صحيح", Toast.LENGTH_LONG).show()
                else { repo.savePurchasePrice(n, p, if (existing == null) "إضافة" else "تعديل يدوي"); products() }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun productHistory(name: String) {
        val p = repo.findProduct(name) ?: return
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), 0, dp(20), dp(10)) }
        box.addView(tv(name, 19f, true, blue)); box.addView(tv("السعر الحالي: ${money(p.currentPurchasePrice)}", 17f, true, green).apply { setPadding(0, dp(6), 0, dp(10)) })
        p.history.asReversed().forEach { r -> box.addView(tv("${r.date}   •   ${money(r.price)}\n${r.note}", 13f, false, muted).apply { setPadding(0, dp(7), 0, dp(7)) }) }
        MaterialAlertDialogBuilder(this).setTitle("سجل سعر الشراء").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("تعديل السعر") { _, _ -> editProduct(name) }.setNegativeButton("إغلاق", null).show()
    }

    private fun reports() {
        currentTitle = "التقارير"
        val c = page("التقارير", "تحليل المبيعات والتكلفة وهامش الربح")
        val inv = repo.invoices(); val sales = inv.sumOf { it.productSales }; val cost = inv.sumOf { it.purchaseCost }; val gross = inv.sumOf { it.grossProfit }; val partner = inv.sumOf { it.commercialProfit }; val net = inv.sumOf { it.netProfit }
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
        statRow(stats, "إجمالي المبيعات", money(sales), green); statRow(stats, "تكلفة الشراء", money(cost), orange); statRow(stats, "هامش الربح قبل الشريك", money(gross), purple); statRow(stats, "أرباح الشركاء", money(partner), blue); statRow(stats, "صافي ربح MGE", money(net), if (net >= 0) green else red)
        c.addView(card(stats))

        section("الربح حسب المنتج")
        val productMap = linkedMapOf<String, Double>()
        inv.forEach { i -> i.items.forEach { item -> productMap[item.name] = (productMap[item.name] ?: 0.0) + item.netProfit } }
        if (productMap.isEmpty()) c.addView(emptyState("لا توجد بيانات", "ستظهر هنا أرباح المنتجات بعد استدعاء الفواتير"))
        else productMap.entries.sortedByDescending { it.value }.forEachIndexed { idx, e ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(15), dp(11), dp(15), dp(11)) }
            row.addView(tv("${idx + 1}. ${e.key}", 14f), LinearLayout.LayoutParams(0, dp(45), 1f)); row.addView(tv(money(e.value), 14f, true, if (e.value >= 0) green else red), LinearLayout.LayoutParams(dp(145), dp(45)))
            c.addView(card(row, 14))
        }

        section("أرباح الشركاء")
        val commercialMap = linkedMapOf<String, Double>()
        inv.filter { it.commercial.isNotBlank() }.forEach { commercialMap[it.commercial] = (commercialMap[it.commercial] ?: 0.0) + it.commercialProfit }
        if (commercialMap.isEmpty()) c.addView(tv("لا توجد فواتير شركاء بعد", 14f, false, muted).apply { setPadding(dp(5), dp(8), dp(5), dp(8)) })
        commercialMap.entries.sortedByDescending { it.value }.forEach { e ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(15), dp(11), dp(15), dp(11)) }
            row.addView(tv("🤝 ${e.key}", 15f, true), LinearLayout.LayoutParams(0, dp(45), 1f)); row.addView(tv(money(e.value), 15f, true, blue), LinearLayout.LayoutParams(dp(145), dp(45))); c.addView(card(row, 14))
        }
    }

    private fun settings() {
        currentTitle = "الإعدادات"
        val c = page("الإعدادات", "إعدادات MGE-Profit والبيانات المحلية")
        settingsCard(c, "قاعدة البيانات", "يتم حفظ الفواتير وأسعار الشراء محليًا على الهاتف. سعر الشراء المثبت داخل الفاتورة لا يتغير عند تعديل السعر الحالي للمنتج.")
        dataTransferCard(c)
        settingsCard(c, "استيراد PDF", "يمكن اختيار فاتورة واحدة أو عدة فواتير. إذا كان رقم الفاتورة موجودًا مسبقًا فلن يتم إدخالها مرة أخرى وسيظهر تنبيه بذلك.")
        settingsCard(c, "أنواع الفواتير", "الفاتورة المباشرة تُحسب من المبيعات ناقص تكلفة الشراء. فاتورة Commercial تخص الشريك ويُخصم منها ربح الشريك للوصول إلى صافي ربح MGE.")
        settingsCard(c, "مشاركة التقارير", "يمكن من تفاصيل الفاتورة مشاركة PDF الأصلي، كما يمكن إنشاء PDF مستقل لهامش الربح.")
        c.addView(card(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(15), dp(18), dp(15)); addView(tv("MGE Profit", 21f, true, blue)); addView(tv("نسخة مستقلة لإدارة أرباح فواتير MGE", 13f, false, muted)) }))
    }

    private fun dataTransferCard(c: LinearLayout) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(15), dp(18), dp(15))
        }
        box.addView(tv("تصدير واستيراد", 19f, true, blue))
        box.addView(tv("نقل بيانات الفواتير والمنتجات وأسعار الشراء إلى هاتف آخر أو الاحتفاظ بنسخة احتياطية.", 13f, false, muted).apply {
            setPadding(0, dp(6), 0, dp(12))
        })
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(button("تصدير", { exportData() }, true, 52), LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(0, 0, dp(5), 0) })
        actions.addView(button("استيراد", { importData() }, false, 52), LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(5), 0, 0, 0) })
        box.addView(actions)
        c.addView(card(box))
    }

    private fun exportData() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "MGE-Profit-Backup.json")
        }, EXPORT_DATA)
    }

    private fun importData() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain", "*/*"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, IMPORT_DATA)
    }

    private fun settingsCard(c: LinearLayout, title: String, text: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(15), dp(18), dp(15)) }
        box.addView(tv(title, 17f, true, blue)); box.addView(tv(text, 13f, false, muted).apply { setPadding(0, dp(6), 0, 0) }); c.addView(card(box))
    }

    private fun editInvoice(invoice: Invoice, preserveEdit: Boolean = false) {
        if (!preserveEdit || editingInvoice?.number != invoice.number) {
            editingInvoice = invoice
            editingDirty = false
        }
        currentTitle = "الفاتورة"
        val c = page("مراجعة الفاتورة #${invoice.number}", "تعديل أسعار الشراء وأسعار الشريك")

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(15), dp(18), dp(15))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val clientBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        clientBox.addView(copyField("اسم الزبون", invoice.clientName.ifBlank { "بدون اسم الزبون" }).apply {
            textSize = 22f
            setTextColor(ink)
            typeface = Typeface.create(typeface, Typeface.BOLD)
        })
        if (invoice.phone.isNotBlank()) clientBox.addView(phoneCopyField(invoice.phone))
        if (invoice.city.isNotBlank()) clientBox.addView(copyField("المدينة", "📍 ${invoice.city}", invoice.city))
        if (invoice.address.isNotBlank()) clientBox.addView(copyField("العنوان", "🏠 ${invoice.address}", invoice.address))
        clientBox.addView(tv("📅 ${invoice.date}", 13f, false, muted).apply { setPadding(0, dp(4), 0, 0) })
        top.addView(clientBox, LinearLayout.LayoutParams(0, -2, 1f))
        val totalBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        totalBox.addView(tv("إجمالي الفاتورة", 12.5f, false, muted).apply { gravity = Gravity.CENTER })
        totalBox.addView(tv(money(invoice.total), 21f, true, blue).apply { gravity = Gravity.CENTER })
        totalBox.addView(tv("الشحن: ${money(invoice.shipping)}", 12f, false, muted).apply { gravity = Gravity.CENTER })
        top.addView(totalBox, LinearLayout.LayoutParams(dp(165), -2))
        head.addView(top)
        val partnerLine = if (invoice.isCommercialInvoice) {
            "🤝 Commercial: ${invoice.commercial}   •   ربح الشريك: ${money(invoice.commercialProfit)}"
        } else "👤 فاتورة مباشرة — لا يوجد شريك"
        head.addView(tv(partnerLine, 13.5f, true, if (invoice.isCommercialInvoice) purple else blue).apply {
            setPadding(0, dp(9), 0, 0)
            gravity = Gravity.CENTER
        })
        c.addView(card(head, 18))

        section("تعديل الأسعار", if (invoice.isCommercialInvoice)
            "أدخل سعر الشراء وسعر الشريك؛ ربح الشريك = سعر البيع − سعر الشريك، وربح MGE = سعر الشريك − سعر الشراء"
        else "أدخل سعر الشراء؛ المتبقي من سعر البيع بعد خصمه هو هامش ربح MGE")

        val table = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(4), dp(2), dp(4))
        }

        val purchaseFields = mutableListOf<Pair<InvoiceItem, EditText>>()
        val partnerFields = mutableListOf<Pair<InvoiceItem, EditText>>()
        val profitLabels = mutableListOf<Pair<InvoiceItem, TextView>>()
        val unitProfitLabels = mutableListOf<Pair<InvoiceItem, TextView>>()
        var refreshSummary: () -> Unit = {}
        val actualShippingField = shippingEditor(c, invoice) {
            editingDirty = true
            refreshSummary()
        }

        fun priceEdit(value: Double, hint: String, accent: Int): EditText = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            textSize = 17f
            gravity = Gravity.CENTER
            setText(if (value > 0.0) fmtMoneyNumber(value) else "")
            this.hint = hint
            setHintTextColor(Color.rgb(175, 177, 184))
            setTextColor(ink)
            setPadding(dp(6), 0, dp(6), 0)
            background = rounded(Color.WHITE, 12, accent)
        }

        invoice.items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = rounded(Color.WHITE, 16, border)
                elevation = dp(1).toFloat()
            }
            row.addView(tv(item.name, 16f, true).apply {
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, 0, 0, dp(7))
            })

            val saleInfo = tv("سعر البيع للوحدة: ${money(item.saleUnitPrice)}", 13f, false, blue).apply {
                gravity = Gravity.RIGHT
                setPadding(0, 0, 0, dp(5))
            }
            row.addView(saleInfo)

            val quantityLine = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(8))
            }
            val quantity = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setSingleLine(true)
                textSize = 16f
                gravity = Gravity.CENTER
                setText(fmtQty(item.quantity))
                setTextColor(ink)
                background = rounded(Color.WHITE, 10, blue)
                setPadding(dp(5), 0, dp(5), 0)
            }
            val minus = button("−", {
                val q = (item.quantity - 1.0).coerceAtLeast(0.0)
                item.quantity = q
                item.saleTotal = item.quantity * item.saleUnitPrice
                quantity.setText(fmtQty(q))
                quantity.setSelection(quantity.text.length)
                editingDirty = true
                refreshSummary()
            }, false, 44).apply { layoutParams = LinearLayout.LayoutParams(dp(50), dp(44)).apply { setMargins(dp(4), 0, dp(4), 0) } }
            val plus = button("+", {
                val q = item.quantity + 1.0
                item.quantity = q
                item.saleTotal = item.quantity * item.saleUnitPrice
                quantity.setText(fmtQty(q))
                quantity.setSelection(quantity.text.length)
                editingDirty = true
                refreshSummary()
            }, false, 44).apply { layoutParams = LinearLayout.LayoutParams(dp(50), dp(44)).apply { setMargins(dp(4), 0, dp(4), 0) } }
            quantityLine.addView(tv("الكمية", 12f, true, muted), LinearLayout.LayoutParams(0, dp(44), 1f))
            quantityLine.addView(minus)
            quantityLine.addView(quantity, LinearLayout.LayoutParams(dp(90), dp(44)))
            quantityLine.addView(plus)
            val delete = button("🗑  إزالة المنتج", {
                MaterialAlertDialogBuilder(this)
                    .setTitle("إزالة المنتج")
                    .setMessage("هل تريد إزالة ${item.name} من هذه الفاتورة؟")
                    .setPositiveButton("إزالة") { _, _ ->
                        invoice.items.remove(item)
                        editingDirty = true
                        editInvoice(invoice, true)
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }, false, 44).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(0, dp(2), 0, dp(7)) } }
            row.addView(quantityLine)

            quantity.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val q = s?.toString()?.replace(",", ".")?.toDoubleOrNull() ?: return
                    if (q < 0.0) return
                    item.quantity = q
                    item.saleTotal = item.quantity * item.saleUnitPrice
                    editingDirty = true
                    refreshSummary()
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
            row.addView(delete)

            val fields = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            fun fieldBox(label: String, field: View, color: Int): LinearLayout {
                return LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(4), dp(5), dp(4), dp(5))
                    background = rounded(Color.rgb(248, 249, 252), 12, border)
                    addView(tv(label, 11.5f, true, color).apply { gravity = Gravity.CENTER })
                    addView(field, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(4), 0, 0) })
                }
            }

            val purchase = priceEdit(item.purchasePriceAtSale, "DH", orange)
            purchaseFields.add(item to purchase)
            fields.addView(fieldBox("سعر الشراء / وحدة", purchase, orange), LinearLayout.LayoutParams(0, dp(91), 1f).apply { setMargins(0, 0, dp(4), 0) })

            if (invoice.isCommercialInvoice) {
                val partner = priceEdit(item.partnerPriceAtSale, "DH", purple)
                partnerFields.add(item to partner)
                fields.addView(fieldBox("سعر الشريك / وحدة", partner, purple), LinearLayout.LayoutParams(0, dp(91), 1f).apply { setMargins(dp(4), 0, 0, 0) })
            }
            row.addView(fields)

            val unitProfit = tv("هامش MGE للوحدة: ${money(if (invoice.isCommercialInvoice) item.partnerPriceAtSale - item.purchasePriceAtSale else item.saleUnitPrice - item.purchasePriceAtSale)}", 12.5f, true, green).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(2))
            }
            unitProfitLabels.add(item to unitProfit)
            row.addView(unitProfit)

            val profit = tv("إجمالي ربح MGE: ${money(item.netProfit)}", 15f, true, if (item.netProfit >= 0) green else red).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = rounded(if (item.netProfit >= 0) Color.rgb(235, 250, 241) else Color.rgb(255, 238, 238), 11)
            }
            profitLabels.add(item to profit)
            row.addView(profit)

            table.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, dp(5), 0, dp(5))
            })
        }
        c.addView(card(table, 16, 4, 8))

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(Color.rgb(236, 251, 242), 14, Color.rgb(190, 235, 208))
        }
        val purchaseTotalLabel = tv("إجمالي الشراء\n${money(invoice.purchaseCost)}", 13f, true, orange).apply { gravity = Gravity.CENTER }
        val partnerTotalLabel = tv("ربح الشريك\n${money(invoice.calculatedPartnerProfit)}", 13f, true, purple).apply { gravity = Gravity.CENTER }
        val grossLabel = tv("هامش الربح\n${money(invoice.grossProfit)}", 13f, true, green).apply { gravity = Gravity.CENTER }
        val netLabel = tv("صافي الربح\n${money(invoice.netProfit)}", 14f, true, if (invoice.netProfit >= 0) green else red).apply { gravity = Gravity.CENTER }
        summary.addView(purchaseTotalLabel, LinearLayout.LayoutParams(0, dp(72), 1f))
        summary.addView(partnerTotalLabel, LinearLayout.LayoutParams(0, dp(72), 1f))
        summary.addView(grossLabel, LinearLayout.LayoutParams(0, dp(72), 1f))
        summary.addView(netLabel, LinearLayout.LayoutParams(0, dp(72), 1f))
        c.addView(summary)

        refreshSummary = {
            val purchase = invoice.items.sumOf { it.purchaseTotal }
            val partner = invoice.items.sumOf { it.partnerTotal }
            val gross = invoice.grossProfit
            val net = invoice.netProfit
            purchaseTotalLabel.text = "إجمالي الشراء\n${money(purchase)}"
            partnerTotalLabel.text = "ربح الشريك\n${money(invoice.items.sumOf { it.saleTotal - it.partnerTotal })}"
            grossLabel.text = "هامش الربح\n${money(gross)}"
            netLabel.text = "صافي الربح\n${money(net)}"
            netLabel.setTextColor(if (net >= 0) green else red)
            profitLabels.forEach { (item, label) ->
                label.text = "إجمالي ربح MGE: ${money(item.netProfit)}"
                label.setTextColor(if (item.netProfit >= 0) green else red)
                label.background = rounded(if (item.netProfit >= 0) Color.rgb(235, 250, 241) else Color.rgb(255, 238, 238), 11)
            }
            unitProfitLabels.forEach { (item, label) ->
                val unit = if (invoice.isCommercialInvoice) item.partnerPriceAtSale - item.purchasePriceAtSale else item.saleUnitPrice - item.purchasePriceAtSale
                label.text = "هامش MGE للوحدة: ${money(unit)}   ×   الكمية ${fmtQty(item.quantity)}"
                label.setTextColor(if (unit >= 0) green else red)
            }
        }

        val allFields = mutableListOf<EditText>()
        allFields.addAll(purchaseFields.map { it.second })
        allFields.addAll(partnerFields.map { it.second })
        allFields.forEach { field ->
            field.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    purchaseFields.forEach { (item, edit) -> item.purchasePriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }
                    partnerFields.forEach { (item, edit) -> item.partnerPriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }
                    editingDirty = true
                    refreshSummary()
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }

        fun saveCurrentEdits(): Boolean {
            purchaseFields.forEach { (item, edit) -> item.purchasePriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }
            partnerFields.forEach { (item, edit) -> item.partnerPriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }
            invoice.actualShippingCost = actualShippingField.text.toString().replace(",", ".").toDoubleOrNull() ?: invoice.shipping
            if (invoice.isCommercialInvoice) invoice.commercialProfit = invoice.calculatedPartnerProfit
            return try {
                repo.updateInvoice(invoice)
                editingInvoice = null
                editingDirty = false
                editingSaveAction = null
                Toast.makeText(this, "تم حفظ تعديلات الفاتورة #${invoice.number}", Toast.LENGTH_LONG).show()
                true
            } catch (e: Exception) {
                Toast.makeText(this, e.message ?: "تعذر حفظ التعديلات", Toast.LENGTH_LONG).show()
                false
            }
        }
        editingSaveAction = ::saveCurrentEdits
        c.addView(button("💾  حفظ التعديلات", {
            if (saveCurrentEdits()) viewInvoice(repo.invoices().first { it.number == invoice.number })
        }, true, 56).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, dp(4), 0, dp(6)) } })
        c.addView(button("🔄  إعادة الحساب", {
            purchaseFields.forEach { (item, edit) -> item.purchasePriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }
            partnerFields.forEach { (item, edit) -> item.partnerPriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }
            refreshSummary()
        }, false, 52).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, 0, 0, dp(6)) } })
        c.addView(button("📄  مشاركة PDF الأصلي", { shareOriginal(invoice) }, false, 52).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, 0, 0, dp(6)) } })
        c.addView(button("📊  مشاركة PDF هامش الربح", { shareMargin(invoice) }, false, 52).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, 0, 0, dp(6)) } })
        c.addView(button("🗑  حذف الفاتورة", { confirmDelete(invoice) }, false, 52))
    }

    private fun confirmDelete(invoice: Invoice) {
        MaterialAlertDialogBuilder(this).setTitle("حذف الفاتورة #${invoice.number}").setMessage("سيتم حذف الفاتورة من التطبيق فقط.").setPositiveButton("حذف") { _, _ ->
            repo.deleteInvoice(invoice.number)
            editingInvoice = null
            editingDirty = false
            editingSaveAction = null
            invoices()
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun pickPdfs() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }, 700)
    }

    @Deprecated("Deprecated Android API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            EXPORT_DATA -> {
                try {
                    contentResolver.openOutputStream(uri)?.use {
                        it.write(repo.exportData().toByteArray(Charsets.UTF_8))
                    } ?: throw IllegalStateException("تعذر فتح الملف للحفظ.")
                    Toast.makeText(this, "تم تصدير البيانات بنجاح", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر التصدير: ${e.message ?: "خطأ غير معروف"}", Toast.LENGTH_LONG).show()
                }
            }
            IMPORT_DATA -> {
                MaterialAlertDialogBuilder(this)
                    .setTitle("استيراد البيانات")
                    .setMessage("سيتم استبدال الفواتير والمنتجات الحالية بالبيانات الموجودة في ملف التصدير. هل تريد المتابعة؟")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("استيراد") { _, _ ->
                        try {
                            val json = contentResolver.openInputStream(uri)?.use {
                                InputStreamReader(it, Charsets.UTF_8).readText()
                            } ?: throw IllegalStateException("تعذر قراءة الملف.")
                            repo.importData(json)
                            Toast.makeText(this, "تم استيراد البيانات بنجاح", Toast.LENGTH_LONG).show()
                            dashboard()
                        } catch (e: Exception) {
                            Toast.makeText(this, "تعذر الاستيراد: ${e.message ?: "ملف غير صالح"}", Toast.LENGTH_LONG).show()
                        }
                    }.show()
            }
            700 -> {
                val uris = mutableListOf<Uri>()
                data.data?.let { uris.add(it) }
                data.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                }
                uris.distinct().forEach { selectedUri ->
                    try {
                        contentResolver.takePersistableUriPermission(selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: Exception) {}
                }
                pendingImports.clear()
                pendingImports.addAll(uris.distinct())
                pendingIndex = 0
                importNext()
            }
        }
    }

    private fun importNext() {
        if (pendingIndex >= pendingImports.size) { pendingImports.clear(); pendingIndex = 0; invoices(); return }
        val uri = pendingImports[pendingIndex]
        try {
            val parsed = PdfInvoiceParser.parse(this, uri, repo)
            if (repo.invoiceExists(parsed.number)) {
                MaterialAlertDialogBuilder(this).setTitle("الفاتورة موجودة مسبقًا").setMessage("الفاتورة رقم #${parsed.number} تم استدعاؤها من قبل، لذلك لن يتم إدخالها مرة أخرى.").setPositiveButton("التالي") { _, _ -> pendingIndex++; importNext() }.show()
            } else review(parsed)
        } catch (e: Exception) {
            MaterialAlertDialogBuilder(this).setTitle("تعذر قراءة الفاتورة").setMessage("لم تتم قراءة ملف PDF بشكل صحيح.\n\n${e.message ?: "خطأ غير معروف"}").setPositiveButton("التالي") { _, _ -> pendingIndex++; importNext() }.setNegativeButton("إيقاف", null).show()
        }
    }

    private fun review(invoice: Invoice) {
        currentTitle = "مراجعة الفاتورة"
        val c = page("مراجعة الفاتورة #${invoice.number}", "تمت قراءة PDF — راجع البيانات قبل الحفظ", false)

        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(15), dp(18), dp(15)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val clientBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        clientBox.addView(copyField("اسم الزبون", invoice.clientName.ifBlank { "بدون اسم الزبون" }).apply {
            textSize = 22f
            setTextColor(ink)
            typeface = Typeface.create(typeface, Typeface.BOLD)
        })
        if (invoice.phone.isNotBlank()) clientBox.addView(phoneCopyField(invoice.phone))
        if (invoice.city.isNotBlank()) clientBox.addView(copyField("المدينة", "📍 ${invoice.city}", invoice.city))
        if (invoice.address.isNotBlank()) clientBox.addView(copyField("العنوان", "🏠 ${invoice.address}", invoice.address))
        clientBox.addView(tv("📅 ${invoice.date}", 13f, false, muted).apply { setPadding(0, dp(4), 0, 0) })
        top.addView(clientBox, LinearLayout.LayoutParams(0, -2, 1f))
        val totalBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        totalBox.addView(tv("إجمالي الفاتورة", 12.5f, false, muted).apply { gravity = Gravity.CENTER })
        totalBox.addView(tv(money(invoice.total), 21f, true, blue).apply { gravity = Gravity.CENTER })
        totalBox.addView(tv("الشحن: ${money(invoice.shipping)}", 12f, false, muted).apply { gravity = Gravity.CENTER })
        top.addView(totalBox, LinearLayout.LayoutParams(dp(165), -2))
        head.addView(top)
        head.addView(tv(if (invoice.isCommercialInvoice) "🤝 Commercial: ${invoice.commercial}   •   ربح الشريك: ${money(invoice.commercialProfit)}" else "👤 فاتورة مباشرة — لا يوجد شريك", 13.5f, true, if (invoice.isCommercialInvoice) purple else blue).apply { gravity = Gravity.CENTER; setPadding(0, dp(9), 0, 0) })
        c.addView(card(head, 18))

        if (invoice.items.isEmpty()) {
            c.addView(tv("⚠ لم يتم التعرف على أي منتج. لا تحفظ الفاتورة قبل التأكد من ملف PDF.", 14f, true, red).apply { setPadding(dp(6), dp(12), dp(6), dp(8)) })
        }

        section("تعديل الأسعار", if (invoice.isCommercialInvoice)
            "سعر الشراء وسعر الشريك يُحسبان كلٌ على حدة × الكمية؛ ربح الشريك = البيع − الشريك، وربح MGE = الشريك − الشراء"
        else "سعر الشراء يُخصم من سعر البيع؛ المتبقي هو هامش ربح MGE")

        val table = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(4), dp(2), dp(4))
        }

        val purchaseFields = mutableListOf<Pair<InvoiceItem, EditText>>()
        val partnerFields = mutableListOf<Pair<InvoiceItem, EditText>>()
        val profitLabels = mutableListOf<Pair<InvoiceItem, TextView>>()
        val unitProfitLabels = mutableListOf<Pair<InvoiceItem, TextView>>()
        var refreshSummary: () -> Unit = {}
        val actualShippingField = shippingEditor(c, invoice) {
            refreshSummary()
        }

        fun priceEdit(value: Double, hint: String, accent: Int): EditText = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            textSize = 17f
            gravity = Gravity.CENTER
            setText(if (value > 0.0) fmtMoneyNumber(value) else "")
            this.hint = hint
            setHintTextColor(Color.rgb(175, 177, 184))
            setTextColor(ink)
            setPadding(dp(6), 0, dp(6), 0)
            background = rounded(Color.WHITE, 12, accent)
        }

        invoice.items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = rounded(Color.WHITE, 16, border)
                elevation = dp(1).toFloat()
            }
            row.addView(tv(item.name, 16f, true).apply {
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, 0, 0, dp(7))
            })

            val saleInfo = tv("سعر البيع للوحدة: ${money(item.saleUnitPrice)}", 13f, false, blue).apply {
                gravity = Gravity.RIGHT
                setPadding(0, 0, 0, dp(5))
            }
            row.addView(saleInfo)

            val quantityLine = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(8))
            }
            val quantity = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setSingleLine(true)
                textSize = 16f
                gravity = Gravity.CENTER
                setText(fmtQty(item.quantity))
                setTextColor(ink)
                background = rounded(Color.WHITE, 10, blue)
                setPadding(dp(5), 0, dp(5), 0)
            }
            val minus = button("−", {
                val q = (item.quantity - 1.0).coerceAtLeast(0.0)
                item.quantity = q
                item.saleTotal = item.quantity * item.saleUnitPrice
                quantity.setText(fmtQty(q))
                quantity.setSelection(quantity.text.length)
                editingDirty = true
                refreshSummary()
            }, false, 44).apply { layoutParams = LinearLayout.LayoutParams(dp(50), dp(44)).apply { setMargins(dp(4), 0, dp(4), 0) } }
            val plus = button("+", {
                val q = item.quantity + 1.0
                item.quantity = q
                item.saleTotal = item.quantity * item.saleUnitPrice
                quantity.setText(fmtQty(q))
                quantity.setSelection(quantity.text.length)
                editingDirty = true
                refreshSummary()
            }, false, 44).apply { layoutParams = LinearLayout.LayoutParams(dp(50), dp(44)).apply { setMargins(dp(4), 0, dp(4), 0) } }
            quantityLine.addView(tv("الكمية", 12f, true, muted), LinearLayout.LayoutParams(0, dp(44), 1f))
            quantityLine.addView(minus)
            quantityLine.addView(quantity, LinearLayout.LayoutParams(dp(90), dp(44)))
            quantityLine.addView(plus)
            val delete = button("🗑  إزالة المنتج", {
                MaterialAlertDialogBuilder(this)
                    .setTitle("إزالة المنتج")
                    .setMessage("هل تريد إزالة ${item.name} من هذه الفاتورة؟")
                    .setPositiveButton("إزالة") { _, _ ->
                        invoice.items.remove(item)
                        editingDirty = true
                        editInvoice(invoice, true)
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }, false, 44).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(0, dp(2), 0, dp(7)) } }
            row.addView(quantityLine)

            quantity.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val q = s?.toString()?.replace(",", ".")?.toDoubleOrNull() ?: return
                    if (q < 0.0) return
                    item.quantity = q
                    item.saleTotal = item.quantity * item.saleUnitPrice
                    editingDirty = true
                    refreshSummary()
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
            row.addView(delete)

            val fields = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            fun fieldBox(label: String, field: View, color: Int): LinearLayout {
                return LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(4), dp(5), dp(4), dp(5))
                    background = rounded(Color.rgb(248, 249, 252), 12, border)
                    addView(tv(label, 11.5f, true, color).apply { gravity = Gravity.CENTER })
                    addView(field, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(4), 0, 0) })
                }
            }

            val purchase = priceEdit(item.purchasePriceAtSale, "DH", orange)
            purchaseFields.add(item to purchase)
            fields.addView(fieldBox("سعر الشراء / وحدة", purchase, orange), LinearLayout.LayoutParams(0, dp(91), 1f).apply { setMargins(0, 0, dp(4), 0) })

            if (invoice.isCommercialInvoice) {
                val partner = priceEdit(item.partnerPriceAtSale, "DH", purple)
                partnerFields.add(item to partner)
                fields.addView(fieldBox("سعر الشريك / وحدة", partner, purple), LinearLayout.LayoutParams(0, dp(91), 1f).apply { setMargins(dp(4), 0, 0, 0) })
            }
            row.addView(fields)

            val unitProfit = tv("هامش MGE للوحدة: ${money(if (invoice.isCommercialInvoice) item.partnerPriceAtSale - item.purchasePriceAtSale else item.saleUnitPrice - item.purchasePriceAtSale)}", 12.5f, true, green).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(2))
            }
            unitProfitLabels.add(item to unitProfit)
            row.addView(unitProfit)

            val profit = tv("إجمالي ربح MGE: ${money(item.netProfit)}", 15f, true, if (item.netProfit >= 0) green else red).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = rounded(if (item.netProfit >= 0) Color.rgb(235, 250, 241) else Color.rgb(255, 238, 238), 11)
            }
            profitLabels.add(item to profit)
            row.addView(profit)

            table.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, dp(5), 0, dp(5))
            })
        }
        c.addView(card(table, 16, 4, 8))

        val summary = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); background = rounded(Color.rgb(236, 251, 242), 14, Color.rgb(190, 235, 208)) }
        val purchaseTotalLabel = tv("إجمالي الشراء\n${money(invoice.purchaseCost)}", 13f, true, orange).apply { gravity = Gravity.CENTER }
        val partnerTotalLabel = tv("ربح الشريك\n${money(invoice.calculatedPartnerProfit)}", 13f, true, purple).apply { gravity = Gravity.CENTER }
        val grossLabel = tv("هامش الربح\n${money(invoice.grossProfit)}", 13f, true, green).apply { gravity = Gravity.CENTER }
        val netLabel = tv("صافي الربح\n${money(invoice.netProfit)}", 14f, true, if (invoice.netProfit >= 0) green else red).apply { gravity = Gravity.CENTER }
        summary.addView(purchaseTotalLabel, LinearLayout.LayoutParams(0, dp(72), 1f)); summary.addView(partnerTotalLabel, LinearLayout.LayoutParams(0, dp(72), 1f)); summary.addView(grossLabel, LinearLayout.LayoutParams(0, dp(72), 1f)); summary.addView(netLabel, LinearLayout.LayoutParams(0, dp(72), 1f))
        c.addView(summary)

        refreshSummary = {
            val purchase = invoice.items.sumOf { it.purchaseTotal }; val partner = invoice.items.sumOf { it.partnerTotal }; val gross = invoice.grossProfit; val net = invoice.netProfit
            purchaseTotalLabel.text = "إجمالي الشراء\n${money(purchase)}"; partnerTotalLabel.text = "ربح الشريك\n${money(invoice.items.sumOf { it.saleTotal - it.partnerTotal })}"; grossLabel.text = "هامش الربح\n${money(gross)}"; netLabel.text = "صافي الربح\n${money(net)}"; netLabel.setTextColor(if (net >= 0) green else red)
            profitLabels.forEach { (item, label) -> label.text = "إجمالي ربح MGE: ${money(item.netProfit)}"; label.setTextColor(if (item.netProfit >= 0) green else red); label.background = rounded(if (item.netProfit >= 0) Color.rgb(235, 250, 241) else Color.rgb(255, 238, 238), 11) }
            unitProfitLabels.forEach { (item, label) -> val unit = if (invoice.isCommercialInvoice) item.partnerPriceAtSale - item.purchasePriceAtSale else item.saleUnitPrice - item.purchasePriceAtSale; label.text = "هامش MGE للوحدة: ${money(unit)}   ×   الكمية ${fmtQty(item.quantity)}"; label.setTextColor(if (unit >= 0) green else red) }
        }
        val allFields = mutableListOf<EditText>(); allFields.addAll(purchaseFields.map { it.second }); allFields.addAll(partnerFields.map { it.second })
        allFields.forEach { field -> field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { purchaseFields.forEach { (item, edit) -> item.purchasePriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }; partnerFields.forEach { (item, edit) -> item.partnerPriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }; refreshSummary() }
            override fun afterTextChanged(s: Editable?) = Unit
        }) }

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        actions.addView(button("إلغاء", { pendingIndex++; importNext() }, false, 54), LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(2), 0, dp(4), 0) })
        actions.addView(button("✓  حفظ الفاتورة", {
            purchaseFields.forEach { (item, edit) -> item.purchasePriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }
            partnerFields.forEach { (item, edit) -> item.partnerPriceAtSale = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0 }
            invoice.actualShippingCost = actualShippingField.text.toString().replace(",", ".").toDoubleOrNull() ?: invoice.shipping
            if (invoice.isCommercialInvoice) invoice.commercialProfit = invoice.calculatedPartnerProfit
            try { purchaseFields.filter { it.first.purchasePriceAtSale > 0 }.forEach { repo.savePurchasePrice(it.first.name, it.first.purchasePriceAtSale, "من الفاتورة #${invoice.number}") }; repo.saveInvoice(invoice); Toast.makeText(this, "تم حفظ الفاتورة #${invoice.number} بنجاح", Toast.LENGTH_LONG).show(); pendingIndex++; importNext() }
            catch (e: Exception) { Toast.makeText(this, e.message ?: "تعذر الحفظ", Toast.LENGTH_LONG).show() }
        }, true, 54), LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(4), 0, dp(2), 0) })
        c.addView(actions)
    }

    private fun fmtQty(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else String.format(Locale.US, "%.2f", v)
    private fun fmtMoneyNumber(v: Double): String = String.format(Locale.US, "%.2f", v)
    private fun money(value: Double): String = String.format(Locale.US, "%.2f DH", value)

    private fun shareOriginal(invoice: Invoice) {
        if (invoice.originalPdfUri.isBlank()) { Toast.makeText(this, "لا يوجد PDF أصلي محفوظ لهذه الفاتورة", Toast.LENGTH_LONG).show(); return }
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, Uri.parse(invoice.originalPdfUri)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "مشاركة PDF الأصلي")) } catch (_: Exception) { Toast.makeText(this, "تعذر مشاركة الملف", Toast.LENGTH_LONG).show() }
    }

    private fun shareMargin(invoice: Invoice) { shareFile(createMarginPdf(listOf(invoice)), "PDF هامش الربح") }
    private fun shareSelectedMargin() { if (selected.isEmpty()) { Toast.makeText(this, "حدد فاتورة واحدة على الأقل", Toast.LENGTH_SHORT).show(); return }; shareFile(createMarginPdf(repo.invoices().filter { selected.contains(it.number) }), "PDF هوامش الربح") }

    private fun shareFile(file: File, title: String) {
        try { val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file); startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, title)) } catch (_: Exception) { Toast.makeText(this, "تعذر إنشاء أو مشاركة PDF", Toast.LENGTH_LONG).show() }
    }

    private fun createMarginPdf(invoices: List<Invoice>): File {
        val file = File(cacheDir, "mge_profit_${System.currentTimeMillis()}.pdf")
        val document = PdfDocument()
        val pageWidth = 595f
        val pageHeight = 842f
        val margin = 40f
        val contentWidth = pageWidth - (margin * 2)
        val bluePdf = Color.rgb(30, 112, 205)
        val darkPdf = Color.rgb(35, 38, 48)
        val grayPdf = Color.rgb(105, 108, 118)
        val lightBluePdf = Color.rgb(235, 244, 255)
        val lightGreenPdf = Color.rgb(235, 250, 241)
        val lightPurplePdf = Color.rgb(246, 241, 255)
        val greenPdf = Color.rgb(29, 145, 83)
        val purplePdf = Color.rgb(93, 67, 172)
        val orangePdf = Color.rgb(220, 137, 17)
        val redPdf = Color.rgb(200, 67, 67)

        var pageNo = 1
        var pdfPage = document.startPage(
            PdfDocument.PageInfo.Builder(pageWidth.toInt(), pageHeight.toInt(), pageNo).create()
        )
        var canvas = pdfPage.canvas
        var y = 42f

        fun finishAndStartPage() {
            document.finishPage(pdfPage)
            pageNo++
            pdfPage = document.startPage(
                PdfDocument.PageInfo.Builder(pageWidth.toInt(), pageHeight.toInt(), pageNo).create()
            )
            canvas = pdfPage.canvas
            y = 42f
        }

        fun ensureSpace(height: Float) {
            if (y + height > pageHeight - 35f) finishAndStartPage()
        }

        fun drawText(
            text: String,
            x: Float,
            top: Float,
            width: Float,
            size: Float,
            color: Int,
            bold: Boolean = false,
            align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL
        ): Float {
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size
                this.color = color
                typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width.toInt())
                .setAlignment(align)
                .setIncludePad(true)
                .build()
            canvas.save()
            canvas.translate(x, top)
            layout.draw(canvas)
            canvas.restore()
            return layout.height.toFloat()
        }

        fun drawRect(left: Float, top: Float, right: Float, bottom: Float, color: Int) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
            canvas.drawRect(left, top, right, bottom, paint)
        }

        fun drawLine(x1: Float, y1: Float, x2: Float, y2: Float, color: Int, stroke: Float = 1f) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
                strokeWidth = stroke
            }
            canvas.drawLine(x1, y1, x2, y2, paint)
        }

        fun moneyPdf(value: Double): String = String.format(Locale.US, "%.2f DH", value)

        fun drawHeader(invoice: Invoice) {
            ensureSpace(145f)
            drawRect(margin, y, margin + 105f, y + 55f, Color.BLACK)
            drawText("MGE", margin, y + 12f, 105f, 24f, Color.WHITE, true, Layout.Alignment.ALIGN_CENTER)
            drawText("MGE PROFIT / هامش الربح", margin + 125f, y + 1f, contentWidth - 125f, 24f, darkPdf, true, Layout.Alignment.ALIGN_OPPOSITE)
            drawText("تقرير هامش الربح وتحليل تكلفة الفاتورة", margin + 125f, y + 33f, contentWidth - 125f, 11f, grayPdf, false, Layout.Alignment.ALIGN_OPPOSITE)
            y += 70f

            drawText("N° : ${invoice.number}", margin, y, 180f, 12f, darkPdf, true)
            drawText("Date : ${invoice.date}", margin + 195f, y, 180f, 12f, darkPdf, false)
            drawText("Client : ${invoice.clientName.ifBlank { "-" }}", margin + 385f, y, contentWidth - 385f, 12f, darkPdf, false, Layout.Alignment.ALIGN_OPPOSITE)
            y += 20f

            if (invoice.phone.isNotBlank() || invoice.city.isNotBlank() || invoice.address.isNotBlank()) {
                val detailsLine = buildString {
                    if (invoice.phone.isNotBlank()) append("Tel : ${invoice.phone}")
                    if (invoice.city.isNotBlank()) {
                        if (isNotEmpty()) append("    ")
                        append("Ville : ${invoice.city}")
                    }
                    if (invoice.address.isNotBlank()) {
                        if (isNotEmpty()) append("    ")
                        append("Adresse : ${invoice.address}")
                    }
                }
                y += drawText(detailsLine, margin, y, contentWidth, 11f, grayPdf) + 4f
            }

            if (invoice.commercial.isNotBlank()) {
                drawRect(margin, y, margin + contentWidth, y + 30f, lightPurplePdf)
                drawText(
                    "Commercial : ${invoice.commercial}",
                    margin + 10f, y + 7f, 250f, 12f, purplePdf, true
                )
                drawText(
                    "ربح الشريك : ${moneyPdf(invoice.commercialProfit)}",
                    margin + 265f, y + 7f, contentWidth - 275f, 12f, purplePdf, true,
                    Layout.Alignment.ALIGN_OPPOSITE
                )
                y += 40f
            }
        }

        fun drawTableHeader(commercial: Boolean) {
            val widths = if (commercial)
                floatArrayOf(188f, 40f, 70f, 70f, 72f, 75f)
            else
                floatArrayOf(250f, 45f, 85f, 85f, 90f)
            val labels = if (commercial)
                arrayOf("المنتج / Produit", "Qté", "بيع", "شراء", "الشريك", "ربح MGE")
            else
                arrayOf("المنتج / Produit", "Qté", "بيع", "شراء", "هامش MGE")

            ensureSpace(34f)
            drawRect(margin, y, margin + contentWidth, y + 34f, bluePdf)
            var x = margin
            labels.forEachIndexed { i, label ->
                drawText(label, x + 4f, y + 8f, widths[i] - 8f, 9.5f, Color.WHITE, true, Layout.Alignment.ALIGN_CENTER)
                x += widths[i]
            }
            y += 34f
        }

        fun drawProductRow(item: InvoiceItem, commercial: Boolean) {
            val widths = if (commercial)
                floatArrayOf(188f, 40f, 70f, 70f, 72f, 75f)
            else
                floatArrayOf(250f, 45f, 85f, 85f, 90f)

            val name = if (item.name.length > 42) item.name.take(39) + "..." else item.name
            val values = if (commercial) {
                arrayOf(
                    name,
                    fmtQty(item.quantity),
                    moneyPdf(item.saleUnitPrice),
                    moneyPdf(item.purchasePriceAtSale),
                    moneyPdf(item.partnerPriceAtSale),
                    moneyPdf(item.netProfit)
                )
            } else {
                arrayOf(
                    name,
                    fmtQty(item.quantity),
                    moneyPdf(item.saleUnitPrice),
                    moneyPdf(item.purchasePriceAtSale),
                    moneyPdf(item.netProfit)
                )
            }

            val rowHeight = 34f
            ensureSpace(rowHeight)
            drawRect(margin, y, margin + contentWidth, y + rowHeight, Color.WHITE)
            var x = margin
            values.forEachIndexed { i, value ->
                val textColor = if (commercial && i == values.lastIndex) {
                    if (item.netProfit >= 0) greenPdf else redPdf
                } else darkPdf
                drawText(value, x + 3f, y + 9f, widths[i] - 6f, 9.2f, textColor, i == values.lastIndex, Layout.Alignment.ALIGN_CENTER)
                x += widths[i]
                if (i < values.lastIndex) drawLine(x, y, x, y + rowHeight, Color.rgb(225, 228, 235))
            }
            drawLine(margin, y + rowHeight, margin + contentWidth, y + rowHeight, Color.rgb(225, 228, 235))
            y += rowHeight
        }

        fun drawSummary(invoice: Invoice) {
            ensureSpace(118f)
            y += 12f
            val boxTop = y
            val boxBottom = y + 105f
            drawRect(margin, boxTop, margin + contentWidth, boxBottom, lightBluePdf)
            drawText("ملخص الفاتورة / Résumé", margin + 10f, boxTop + 8f, contentWidth - 20f, 13f, bluePdf, true, Layout.Alignment.ALIGN_OPPOSITE)

            val purchase = invoice.purchaseCost
            val partnerProfit = if (invoice.isCommercialInvoice) invoice.calculatedPartnerProfit else 0.0
            val mgeProfit = invoice.netProfit
            val beforePartner = invoice.grossProfit
            val colW = contentWidth / 4f
            val topValue = boxTop + 38f

            val labels = arrayOf("المبيعات", "تكلفة الشراء", "ربح الشريك", "صافي ربح MGE")
            val values = arrayOf(moneyPdf(invoice.productSales), moneyPdf(purchase), moneyPdf(partnerProfit), moneyPdf(mgeProfit))
            val colors = arrayOf(bluePdf, orangePdf, purplePdf, if (mgeProfit >= 0) greenPdf else redPdf)

            for (i in 0 until 4) {
                val left = margin + i * colW
                drawText(labels[i], left + 4f, topValue, colW - 8f, 10f, grayPdf, true, Layout.Alignment.ALIGN_CENTER)
                drawText(values[i], left + 4f, topValue + 19f, colW - 8f, 12f, colors[i], true, Layout.Alignment.ALIGN_CENTER)
                if (i > 0) drawLine(left, boxTop + 34f, left, boxBottom - 8f, Color.rgb(205, 215, 228))
            }
            drawText(
                "هامش الربح قبل الشريك: ${moneyPdf(beforePartner)}",
                margin + 10f, boxBottom - 25f, contentWidth - 20f, 9.5f, grayPdf, false,
                Layout.Alignment.ALIGN_OPPOSITE
            )
            y = boxBottom + 14f
        }

        if (invoices.isEmpty()) {
            drawText("لا توجد فواتير لإعداد تقرير هامش الربح.", margin, y, contentWidth, 14f, grayPdf, false, Layout.Alignment.ALIGN_CENTER)
        } else {
            invoices.forEachIndexed { invoiceIndex, invoice ->
                if (invoiceIndex > 0) {
                    ensureSpace(35f)
                    drawLine(margin, y, margin + contentWidth, y, Color.rgb(210, 214, 222), 1.5f)
                    y += 18f
                }

                drawHeader(invoice)
                val commercial = invoice.isCommercialInvoice
                drawTableHeader(commercial)
                invoice.items.forEach { item -> drawProductRow(item, commercial) }
                drawSummary(invoice)

                if (invoice.shipping > 0.0 || invoice.actualShippingCost > 0.0) {
                    drawText("الشحن في الفاتورة: ${moneyPdf(invoice.shipping)}   •   الشحن الفعلي: ${moneyPdf(invoice.actualShippingCost)}", margin, y, contentWidth, 10f, grayPdf, false, Layout.Alignment.ALIGN_OPPOSITE)
                    y += 15f
                    if (invoice.shippingAdjustment != 0.0) {
                        drawText("فرق الشحن المؤثر على الربح: ${moneyPdf(invoice.shippingAdjustment)}", margin, y, contentWidth, 9.5f, if (invoice.shippingAdjustment > 0) redPdf else greenPdf, false, Layout.Alignment.ALIGN_OPPOSITE)
                        y += 18f
                    }
                }
                drawText(
                    "MGE-Profit  •  تقرير داخلي لهامش الربح",
                    margin, y, contentWidth, 8.5f, grayPdf, false, Layout.Alignment.ALIGN_CENTER
                )
                y += 18f
            }
        }

        document.finishPage(pdfPage)
        file.outputStream().use { document.writeTo(it) }
        document.close()
        return file
    }
}
