package com.mge.profit

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.util.Locale

object PdfInvoiceParser {
    fun parse(context: Context, uri: Uri, repo: Repository): Invoice {
        PDFBoxResourceLoader.init(context.applicationContext)
        val file = File.createTempFile("mge_invoice_", ".pdf", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "تعذر فتح ملف PDF" }
                file.outputStream().use { output -> input.copyTo(output) }
            }
            val raw = PDDocument.load(file).use { PDFTextStripper().getText(it) }
            return parseText(raw, repo).apply { originalPdfUri = uri.toString() }
        } finally {
            file.delete()
        }
    }

    private fun parseText(raw: String, repo: Repository): Invoice {
        val lines = raw.lines().map(::clean).filter { it.isNotBlank() }
        val number = findNumber(lines) ?: throw IllegalArgumentException("لم أستطع استخراج رقم الفاتورة")
        val invoice = Invoice(
            number = number,
            date = findDate(lines),
            clientName = findField(lines, "Client"),
            phone = findPhone(lines),
            city = findField(lines, "Ville"),
            address = findField(lines, "Adresse"),
            trackingNumber = findTracking(lines),
            commercial = findCommercial(lines),
            shipping = findAmount(lines, "frais de livraison", "livraison"),
            actualShippingCost = findAmount(lines, "frais de livraison", "livraison"),
            commercialProfit = findPartnerProfit(lines),
            total = findAmount(lines, "total facture"),
            deliveryReceived = findDeliveryReceived(lines)
        )

        var inProducts = false
        for (line in lines) {
            val lower = line.lowercase(Locale.getDefault())
            if (lower.contains("produit") && lower.contains("qt")) {
                inProducts = true
                continue
            }
            if (!inProducts) continue
            if (lower.contains("frais de livraison") || lower.contains("total facture")) break

            parseProductLine(line)?.let { (name, qty, unit, total) ->
                invoice.items.add(
                    InvoiceItem(name, qty, unit, total, repo.currentPurchase(name))
                )
            }
        }

        if (invoice.total == 0.0) invoice.total = invoice.productSales + invoice.shipping
        return invoice
    }

    private fun clean(value: String): String = value
        .replace("\u0000", "")
        .replace("\uFFFD", "")
        .replace(Regex("[\\u200E\\u200F\\u202A-\\u202E]"), "")
        .trim()

    private fun findNumber(lines: List<String>): String? {
        val regex = Regex("(?:N°|No|Nº|Facture|Invoice|فاتورة)\\s*[:#-]?\\s*(\\d+)", RegexOption.IGNORE_CASE)
        return lines.firstNotNullOfOrNull { regex.find(it)?.groupValues?.getOrNull(1) }
    }

    private fun findDate(lines: List<String>): String =
        lines.firstNotNullOfOrNull { Regex("\\b\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}\\b").find(it)?.value } ?: ""

    private fun findField(lines: List<String>, label: String): String {
        val normalRegex = Regex("(?i)${Regex.escape(label)}\\s*:\\s*(.*?)(?=\\s+(?:Tel|Adresse|Ville|Statut|Commercial)\\s*:|$)")
        lines.firstNotNullOfOrNull { line ->
            normalRegex.find(line)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }
        }?.let { return it }

        // PDFBox may return RTL lines in visual/reversed order.
        val line = lines.firstOrNull { it.lowercase(Locale.getDefault()).contains(label.lowercase(Locale.getDefault())) } ?: return ""
        val lower = line.lowercase(Locale.getDefault())
        val targetPos = lower.lastIndexOf(label.lowercase(Locale.getDefault()))
        if (targetPos < 0) return ""
        val before = line.substring(0, targetPos).trim(' ', ':', '-')
        val previousMatches = Regex("(?i)(Tel|Adresse|Ville|Client|Statut|Commercial)\\s*:?").findAll(before).toList()
        if (previousMatches.isNotEmpty()) {
            val previous = previousMatches.last()
            val value = before.substring(previous.range.last + 1).trim(' ', ':', '-')
            if (value.isNotBlank()) return value
        }
        return before
    }

    private fun findPhone(lines: List<String>): String {
        val clientLine = lines.firstOrNull { it.lowercase(Locale.getDefault()).contains("client") } ?: return ""
        return Regex("Tel\\s*:\\s*(\\+?\\d{8,15})", RegexOption.IGNORE_CASE).find(clientLine)?.groupValues?.get(1)
            ?: Regex("\\b0\\d{9}\\b").find(clientLine)?.value
            ?: ""
    }

    private fun findDeliveryReceived(lines: List<String>): Boolean {
        for (line in lines) {
            val lower = line.lowercase(Locale.getDefault())
            val notReceived = lower.contains("non reçu") || lower.contains("non recu") ||
                lower.contains("non livré") || lower.contains("non livre") ||
                lower.contains("لم يتم الاستلام") || lower.contains("لم يستلم") ||
                lower.contains("غير مستلم") || lower.contains("لم يتم تسليم")
            if (notReceived) return false
            val received = lower.contains("reçu") || lower.contains("recu") ||
                lower.contains("تم الاستلام") || lower.contains("تم تسليم")
            if (received) return true
        }
        return true
    }

    private fun findTracking(lines: List<String>): String {
        for (line in lines) {
            val match = Regex("(?i)(?:N°|No|Nº)?\\s*suivi\\s*:?\\s*([A-Za-z0-9_-]+)").find(line)
            if (match != null) return match.groupValues[1].trim()
        }
        return ""
    }

    private fun findCommercial(lines: List<String>): String {
        val line = lines.firstOrNull { it.lowercase(Locale.getDefault()).startsWith("commercial") } ?: return ""
        return Regex("(?i)^commercial\\s+(.+?)(?:\\s+Tel\\s*:|$)").find(line)?.groupValues?.get(1)?.trim() ?: ""
    }

    private fun findAmount(lines: List<String>, vararg labels: String): Double {
        for (line in lines) {
            val lower = line.lowercase(Locale.getDefault())
            if (labels.any { lower.contains(it.lowercase(Locale.getDefault())) }) {
                Regex("\\d+(?:[.,]\\d+)?").findAll(line).lastOrNull()?.let { return numberValue(it.value) ?: 0.0 }
            }
        }
        return 0.0
    }

    private fun findPartnerProfit(lines: List<String>): Double {
        for (line in lines) {
            val lower = line.lowercase(Locale.getDefault())
            if (lower.contains("profit") || lower.contains("pa ner") || lower.contains("الشريك")) {
                Regex("\\d+(?:[.,]\\d+)?").findAll(line).lastOrNull()?.let { return numberValue(it.value) ?: 0.0 }
            }
        }
        return 0.0
    }

    private fun parseProductLine(line: String): ProductLine? {
        val regex = Regex("^(.+?)\\s+(\\d+(?:[.,]\\d+)?)\\s+(\\d+(?:[.,]\\d+)?)\\s+(\\d+(?:[.,]\\d+)?)$")
        val match = regex.find(line) ?: return null
        val name = match.groupValues[1].trim()
        if (name.length < 2 || looksLikeLabel(name)) return null
        val qty = numberValue(match.groupValues[2]) ?: return null
        val unit = numberValue(match.groupValues[3]) ?: return null
        val total = numberValue(match.groupValues[4]) ?: return null
        if (qty <= 0.0) return null
        return ProductLine(name, qty, unit, total)
    }

    private data class ProductLine(val name: String, val qty: Double, val unit: Double, val total: Double)

    private fun numberValue(value: String): Double? = value.replace(" ", "").replace(",", ".").toDoubleOrNull()

    private fun looksLikeLabel(value: String): Boolean {
        val lower = value.lowercase(Locale.getDefault())
        return lower.contains("date") || lower.contains("client") || lower.contains("tel") ||
            lower.contains("ville") || lower.contains("adresse") || lower.contains("commercial") ||
            lower.contains("statut") || lower.contains("expédition") || lower.contains("expedition") ||
            lower.contains("suivi") || lower.contains("livraison") || lower.contains("total facture") ||
            lower.contains("à payer") || lower.contains("a payer") || lower.contains("produit")
    }
}
