package com.mge.profit

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.util.Locale

object PdfInvoiceParser {
    fun parse(context: Context, uri: Uri, repo: Repository): Invoice {
        PDFBoxResourceLoader.init(context.applicationContext)
        val file = File.createTempFile("invoice_", ".pdf", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "تعذر فتح ملف PDF" }
                file.outputStream().use { out -> input.copyTo(out) }
            }
            val text = PDDocument.load(file).use { document ->
                PDFTextStripper().getText(document)
            }
            return parseText(text, repo)
        } finally {
            file.delete()
        }
    }

    private fun parseText(raw: String, repo: Repository): Invoice {
        val lines = raw.lines().map { clean(it) }.filter { it.isNotBlank() }
        val number = findNumber(lines) ?: throw IllegalArgumentException("لم أستطع استخراج رقم الفاتورة")
        val invoice = Invoice(
            number = number,
            date = findDate(lines),
            clientName = valueAfterLabel(lines, "client", "nom", "الزبون", "العميل"),
            phone = valueAfterLabel(lines, "tel", "telephone", "téléphone", "phone", "الهاتف"),
            city = valueAfterLabel(lines, "ville", "city", "المدينة"),
            address = valueAfterLabel(lines, "adresse", "address", "العنوان"),
            commercial = findCommercial(lines),
            shipping = findAmountForLabel(lines, "livraison", "shipping", "frais de livraison", "الشحن"),
            commercialProfit = findProfit(lines),
            total = findAmountForLabel(lines, "total facture", "total", "المجموع")
        )

        val start = lines.indexOfFirst { it.lowercase(Locale.getDefault()).contains("produit") }
        if (start >= 0) {
            var i = start + 1
            while (i + 3 < lines.size) {
                val qty = numberValue(lines[i])
                val unit = numberValue(lines[i + 1])
                val total = numberValue(lines[i + 2])
                if (qty != null && unit != null && total != null && qty > 0) {
                    val name = lines[i - 1]
                    if (isProductName(name)) {
                        invoice.items.add(InvoiceItem(name, qty, unit, total, repo.currentPurchase(name)))
                        i += 3
                        continue
                    }
                }
                i++
                if (lines[i].lowercase(Locale.getDefault()).contains("frais de livraison")) break
            }
        }

        if (invoice.total == 0.0) invoice.total = invoice.productSales + invoice.shipping
        return invoice
    }

    private fun clean(value: String): String = value
        .replace("\u0000", "")
        .replace("\uFFFD", "")
        .replace(Regex("[\\u200E\\u200F\\u202A-\\u202E]"), "")
        .trim()

    private fun findNumber(lines: List<String>): String? {
        val regex = Regex("(?:N°|No|Nº|Facture|Invoice|فاتورة|رقم الفاتورة)\\s*[:#-]?\\s*(\\d+)", RegexOption.IGNORE_CASE)
        return lines.firstNotNullOfOrNull { regex.find(it)?.groupValues?.getOrNull(1) }
    }

    private fun findDate(lines: List<String>): String =
        lines.firstNotNullOfOrNull { Regex("\\b\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}\\b").find(it)?.value } ?: ""

    private fun valueAfterLabel(lines: List<String>, vararg labels: String): String {
        for (index in lines.indices) {
            val line = lines[index]
            val lower = line.lowercase(Locale.getDefault())
            labels.forEach { label ->
                val pos = lower.indexOf(label.lowercase(Locale.getDefault()))
                if (pos >= 0) {
                    val rest = line.substring(pos + label.length).trim(' ', ':', '-', '/')
                    if (rest.isNotBlank() && !rest.matches(Regex("[0-9 .+()-]+"))) return rest
                    if (index + 1 < lines.size) {
                        val next = lines[index + 1]
                        if (next.isNotBlank() && !looksLikeLabel(next)) return next
                    }
                }
            }
        }
        return ""
    }

    private fun findCommercial(lines: List<String>): String {
        lines.firstNotNullOfOrNull { line ->
            val m = Regex("(?i)commercial\\s*[:/-]?\\s*(.+)").find(line)
            m?.groupValues?.getOrNull(1)?.trim()
        }?.let { return it }
        return ""
    }

    private fun findAmountForLabel(lines: List<String>, vararg labels: String): Double {
        for (line in lines) {
            val lower = line.lowercase(Locale.getDefault())
            if (labels.any { lower.contains(it.lowercase(Locale.getDefault())) }) {
                val values = Regex("\\d+(?:[.,]\\d+)?").findAll(line).mapNotNull { numberValue(it.value) }.toList()
                if (values.isNotEmpty()) return values.last()
            }
        }
        return 0.0
    }

    private fun findProfit(lines: List<String>): Double {
        for (line in lines) {
            if (line.lowercase(Locale.getDefault()).contains("profit")) {
                Regex("\\d+(?:[.,]\\d+)?").findAll(line).lastOrNull()?.let { return numberValue(it.value) ?: 0.0 }
            }
        }
        return 0.0
    }

    private fun numberValue(value: String): Double? = value.replace(" ", "").replace(",", ".").toDoubleOrNull()

    private fun isProductName(value: String): Boolean =
        value.length >= 2 &&
            !looksLikeLabel(value) &&
            !value.equals("Qté", true) &&
            !value.equals("Prix", true) &&
            !value.equals("Total", true)

    private fun looksLikeLabel(value: String): Boolean {
        val lower = value.lowercase(Locale.getDefault())
        return lower.contains("date") || lower.contains("client") || lower.contains("tel") ||
            lower.contains("ville") || lower.contains("adresse") || lower.contains("commercial") ||
            lower.contains("statut") || lower.contains("expédition") || lower.contains("expedition") ||
            lower.contains("suivi") || lower.contains("livraison") || lower.contains("total facture") ||
            lower.contains("à payer") || lower.contains("a payer") || lower.contains("produit")
    }
}
