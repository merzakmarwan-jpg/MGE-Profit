package com.mge.profit
import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
object PdfInvoiceParser{
 fun parse(c:Context,u:Uri,r:Repository):Invoice{PDFBoxResourceLoader.init(c.applicationContext);val f=File.createTempFile("invoice_",".pdf",c.cacheDir);c.contentResolver.openInputStream(u).use{input->requireNotNull(input);f.outputStream().use{out->input.copyTo(out)}};val t=PDDocument.load(f).use{PDFTextStripper().getText(it)};f.delete();return parseText(t,r)}
 private fun parseText(t:String,r:Repository):Invoice{val num=first(t,listOf("(?i)(?:Facture|Invoice|N[°o]|No)\\s*[:#-]?\\s*(\\d+)","(?i)(?:فاتورة|رقم الفاتورة)\\s*[:#-]?\\s*(\\d+)"))?:throw IllegalArgumentException("لم أستطع استخراج رقم الفاتورة.");val i=Invoice(num,date=first(t,listOf("(?i)(?:Date|التاريخ)\\s*[:#-]?\\s*([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4})"))?:"",clientName=first(t,listOf("(?i)(?:Client|Nom|الزبون|العميل)\\s*[:#-]?\\s*(.+)"))?:"",phone=first(t,listOf("(?i)(?:Tel|T[ée]l[ée]phone|Phone|الهاتف)\\s*[:#-]?\\s*([+0-9][0-9\\s-]{7,})"))?:"",city=first(t,listOf("(?i)(?:Ville|City|المدينة)\\s*[:#-]?\\s*(.+)"))?:"",address=first(t,listOf("(?i)(?:Adresse|Address|العنوان)\\s*[:#-]?\\s*(.+)"))?:"",commercial=first(t,listOf("(?i)(?:Commercial|Commerciale|التجاري)\\s*[:#-]?\\s*(.+)"))?:"",shipping=num(first(t,listOf("(?i)(?:Livraison|Shipping|Frais de livraison|الشحن)\\s*[:#-]?\\s*([0-9.,]+)"))),commercialProfit=num(first(t,listOf("(?i)(?:B[ée]n[ée]fice\\s+(?:commercial|commerciale)|Profit\\s+commercial|ربح التجاري)\\s*[:#-]?\\s*([0-9.,]+)"))),total=num(first(t,listOf("(?i)(?:TOTAL|Total|المجموع)\\s*[:#-]?\\s*([0-9.,]+)"))));val row=Regex("""^(.+?)\\s+(\\d+(?:[.,]\\d+)?)\\s+(\\d+(?:[.,]\\d+)?)\\s+(\\d+(?:[.,]\\d+)?)$""");t.lines().map{it.trim()}.filter{it.isNotBlank()}.forEach{line->val m=row.matchEntire(line)?:return@forEach;val n=m.groupValues[1].trim(' ','|','-',':');val q=num(m.groupValues[2]);val u=num(m.groupValues[3]);val s=num(m.groupValues[4]);if(n.length>=2&&q>0)i.items.add(InvoiceItem(n,q,u,s,r.currentPurchase(n)))};if(i.total==0.0)i.total=i.productSales+i.shipping;return i}
 private fun first(t:String,ps:List<String>)=ps.firstNotNullOfOrNull{Regex(it,RegexOption.MULTILINE).find(t)?.groupValues?.getOrNull(1)?.trim()}
 private fun num(s:String?)=s?.replace(" ","")?.replace(",",".")?.toDoubleOrNull()?:0.0
}
