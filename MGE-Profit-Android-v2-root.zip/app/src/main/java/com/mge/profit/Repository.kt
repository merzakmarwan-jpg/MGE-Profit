package com.mge.profit
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
class Repository(c:Context){
 private val p=c.getSharedPreferences("mge_profit_db",0)
 fun invoices():MutableList<Invoice>{val a=JSONArray(p.getString("invoices","[]"));return MutableList(a.length()){fromInvoice(a.getJSONObject(it))}}
 fun products():MutableList<Product>{val a=JSONArray(p.getString("products","[]"));return MutableList(a.length()){fromProduct(a.getJSONObject(it))}}
 fun findProduct(n:String)=products().firstOrNull{it.name.trim().equals(n.trim(),true)}
 fun currentPurchase(n:String)=findProduct(n)?.currentPurchasePrice?:0.0
 fun savePurchasePrice(n:String,price:Double,note:String=""){val list=products();val x=list.firstOrNull{it.name.trim().equals(n.trim(),true)};val d=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date());if(x==null)list.add(Product(n.trim(),price,mutableListOf(PurchaseRecord(d,price,note))))else{x.currentPurchasePrice=price;x.history.add(PurchaseRecord(d,price,note))};saveProducts(list)}
 fun saveInvoice(i:Invoice){val l=invoices();if(l.any{it.number==i.number})throw IllegalArgumentException("الفاتورة رقم ${i.number} موجودة مسبقاً.");l.add(0,i);saveInvoices(l)}
 fun deleteInvoice(n:String){saveInvoices(invoices().filterNot{it.number==n}.toMutableList())}
 private fun saveProducts(l:MutableList<Product>){val a=JSONArray();l.forEach{a.put(JSONObject().apply{put("name",it.name);put("current",it.currentPurchasePrice);put("history",JSONArray().apply{it.history.forEach{x->put(JSONObject().apply{put("date",x.date);put("price",x.price);put("note",x.note)})}})}};p.edit().putString("products",a.toString()).apply()}
 private fun saveInvoices(l:MutableList<Invoice>){val a=JSONArray();l.forEach{i->a.put(JSONObject().apply{put("number",i.number);put("date",i.date);put("client",i.clientName);put("phone",i.phone);put("city",i.city);put("address",i.address);put("commercial",i.commercial);put("shipping",i.shipping);put("commercialProfit",i.commercialProfit);put("total",i.total);put("items",JSONArray().apply{i.items.forEach{x->put(JSONObject().apply{put("name",x.name);put("qty",x.quantity);put("saleUnit",x.saleUnitPrice);put("saleTotal",x.saleTotal);put("purchase",x.purchasePriceAtSale)})}})})};p.edit().putString("invoices",a.toString()).apply()}
 private fun fromProduct(o:JSONObject):Product{val a=o.optJSONArray("history")?:JSONArray();val h=MutableList(a.length()){val x=a.getJSONObject(it);PurchaseRecord(x.optString("date"),x.optDouble("price"),x.optString("note"))};return Product(o.optString("name"),o.optDouble("current"),h)}
 private fun fromInvoice(o:JSONObject):Invoice{val a=o.optJSONArray("items")?:JSONArray();val it=MutableList(a.length()){val x=a.getJSONObject(it);InvoiceItem(x.optString("name"),x.optDouble("qty"),x.optDouble("saleUnit"),x.optDouble("saleTotal"),x.optDouble("purchase"))};return Invoice(o.optString("number"),o.optString("date"),o.optString("client"),o.optString("phone"),o.optString("city"),o.optString("address"),o.optString("commercial"),o.optDouble("shipping"),o.optDouble("commercialProfit"),o.optDouble("total"),it)}
}
