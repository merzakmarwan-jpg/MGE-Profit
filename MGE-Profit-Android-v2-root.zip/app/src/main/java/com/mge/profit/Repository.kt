package com.mge.profit

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Repository(context: Context) {
    private val prefs = context.getSharedPreferences("mge_profit_db", Context.MODE_PRIVATE)

    fun invoices(): MutableList<Invoice> {
        val array = JSONArray(prefs.getString("invoices", "[]"))
        return MutableList(array.length()) { i -> fromInvoice(array.getJSONObject(i)) }
    }

    fun products(): MutableList<Product> {
        val array = JSONArray(prefs.getString("products", "[]"))
        return MutableList(array.length()) { i -> fromProduct(array.getJSONObject(i)) }
    }

    fun findProduct(name: String): Product? = products().firstOrNull {
        it.name.trim().equals(name.trim(), ignoreCase = true)
    }

    fun currentPurchase(name: String): Double = findProduct(name)?.currentPurchasePrice ?: 0.0

    fun savePurchasePrice(name: String, price: Double, note: String = "") {
        val cleanName = name.trim()
        if (cleanName.isBlank()) return
        val list = products()
        val existing = list.firstOrNull { it.name.trim().equals(cleanName, ignoreCase = true) }
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (existing == null) {
            list.add(Product(cleanName, price, mutableListOf(PurchaseRecord(date, price, note))))
        } else {
            existing.currentPurchasePrice = price
            existing.history.add(PurchaseRecord(date, price, note))
        }
        saveProducts(list)
    }

    fun invoiceExists(number: String): Boolean = invoices().any { it.number == number }

    fun saveInvoice(invoice: Invoice) {
        val list = invoices()
        if (list.any { it.number == invoice.number }) {
            throw IllegalArgumentException("الفاتورة رقم ${invoice.number} موجودة مسبقاً.")
        }
        list.add(0, invoice)
        saveInvoices(list)
    }

    fun deleteInvoice(number: String) {
        saveInvoices(invoices().filterNot { it.number == number }.toMutableList())
        val remaining = archives().mapNotNull { archive ->
            val kept = archive.invoiceNumbers.filterNot { it == number }.toMutableList()
            if (kept.isEmpty()) null else archive.copy(invoiceNumbers = kept)
        }.toMutableList()
        saveArchives(remaining)
    }

    fun updateInvoice(invoice: Invoice) {
        val list = invoices()
        val index = list.indexOfFirst { it.number == invoice.number }
        if (index < 0) throw IllegalArgumentException("الفاتورة رقم ${invoice.number} غير موجودة.")
        list[index] = invoice
        saveInvoices(list)
    }

    fun deleteInvoices(numbers: Set<String>) {
        saveInvoices(invoices().filterNot { numbers.contains(it.number) }.toMutableList())
        val remaining = archives().mapNotNull { archive ->
            val kept = archive.invoiceNumbers.filterNot { numbers.contains(it) }.toMutableList()
            if (kept.isEmpty()) null else archive.copy(invoiceNumbers = kept)
        }.toMutableList()
        saveArchives(remaining)
    }

    fun archives(): MutableList<AccountingArchive> {
        val array = JSONArray(prefs.getString("accountingArchives", "[]"))
        return MutableList(array.length()) { i ->
            val json = array.getJSONObject(i)
            val numbers = json.optJSONArray("invoiceNumbers") ?: JSONArray()
            AccountingArchive(
                number = json.optInt("number"),
                date = json.optString("date"),
                invoiceNumbers = MutableList(numbers.length()) { n -> numbers.optString(n) }
            )
        }.sortedByDescending { it.number }.toMutableList()
    }

    fun isInvoiceArchived(number: String): Boolean = archives().any { it.invoiceNumbers.contains(number) }

    fun unarchivedInvoices(): List<Invoice> {
        val archived = archives().flatMap { it.invoiceNumbers }.toSet()
        return invoices().filterNot { archived.contains(it.number) }
    }

    fun nextArchiveNumber(): Int {
        val last = prefs.getInt("archiveSequence", 0)
        val maxExisting = archives().maxOfOrNull { it.number } ?: 0
        return maxOf(last, maxExisting) + 1
    }

    fun createAccountingArchive(invoiceNumbers: List<String>, date: String): AccountingArchive {
        val clean = invoiceNumbers.distinct().filter { number -> invoices().any { it.number == number } && !isInvoiceArchived(number) }
        if (clean.isEmpty()) throw IllegalArgumentException("لا توجد فواتير جديدة للمحاسبة.")
        val archive = AccountingArchive(nextArchiveNumber(), date, clean.toMutableList())
        val list = archives()
        list.add(archive)
        saveArchives(list)
        prefs.edit().putInt("archiveSequence", archive.number).apply()
        return archive
    }

    fun restoreArchiveInvoices(number: Int, invoiceNumbers: Collection<String>): Int {
        val requested = invoiceNumbers.toSet()
        if (requested.isEmpty()) return 0
        val list = archives()
        val index = list.indexOfFirst { it.number == number }
        if (index < 0) return 0
        val archive = list[index]
        val selected = archive.invoiceNumbers.filter { requested.contains(it) }.toSet()
        if (selected.isEmpty()) return 0
        val remaining = archive.invoiceNumbers.filterNot { requested.contains(it) }.toMutableList()
        if (remaining.isEmpty()) list.removeAt(index)
        else list[index] = archive.copy(invoiceNumbers = remaining)
        saveArchives(list)
        return selected.size
    }

    fun restoreArchive(number: Int): AccountingArchive? {
        val list = archives()
        val found = list.firstOrNull { it.number == number } ?: return null
        saveArchives(list.filterNot { it.number == number }.toMutableList())
        return found
    }

    fun exportData(): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("invoices", JSONArray(prefs.getString("invoices", "[]")))
        root.put("products", JSONArray(prefs.getString("products", "[]")))
        root.put("accountingArchives", JSONArray(prefs.getString("accountingArchives", "[]")))
        root.put("archiveSequence", prefs.getInt("archiveSequence", 0))
        return root.toString(2)
    }

    fun importData(jsonText: String) {
        val root = JSONObject(jsonText)
        val invoicesArray = root.optJSONArray("invoices") ?: throw IllegalArgumentException("ملف التصدير لا يحتوي على الفواتير.")
        val productsArray = root.optJSONArray("products") ?: throw IllegalArgumentException("ملف التصدير لا يحتوي على المنتجات.")
        val archivesArray = root.optJSONArray("accountingArchives") ?: JSONArray()
        val archiveSequence = root.optInt("archiveSequence", 0)
        prefs.edit()
            .putString("invoices", invoicesArray.toString())
            .putString("products", productsArray.toString())
            .putString("accountingArchives", archivesArray.toString())
            .putInt("archiveSequence", archiveSequence)
            .apply()
    }

    private fun saveProducts(list: MutableList<Product>) {
        val array = JSONArray()
        list.forEach { product ->
            val history = JSONArray()
            product.history.forEach { record ->
                history.put(JSONObject().apply {
                    put("date", record.date)
                    put("price", record.price)
                    put("note", record.note)
                })
            }
            array.put(JSONObject().apply {
                put("name", product.name)
                put("current", product.currentPurchasePrice)
                put("history", history)
            })
        }
        prefs.edit().putString("products", array.toString()).apply()
    }

    private fun saveInvoices(list: MutableList<Invoice>) {
        val array = JSONArray()
        list.forEach { invoice ->
            val items = JSONArray()
            invoice.items.forEach { item ->
                items.put(JSONObject().apply {
                    put("name", item.name)
                    put("qty", item.quantity)
                    put("saleUnit", item.saleUnitPrice)
                    put("saleTotal", item.saleTotal)
                    put("purchase", item.purchasePriceAtSale)
                    put("partnerPrice", item.partnerPriceAtSale)
                })
            }
            array.put(JSONObject().apply {
                put("number", invoice.number)
                put("date", invoice.date)
                put("client", invoice.clientName)
                put("phone", invoice.phone)
                put("city", invoice.city)
                put("address", invoice.address)
                put("trackingNumber", invoice.trackingNumber)
                put("commercial", invoice.commercial)
                put("shipping", invoice.shipping)
                put("actualShippingCost", invoice.actualShippingCost)
                put("commercialProfit", invoice.commercialProfit)
                put("total", invoice.total)
                put("originalPdfUri", invoice.originalPdfUri)
                put("deliveryReceived", invoice.deliveryReceived)
                put("items", items)
            })
        }
        prefs.edit().putString("invoices", array.toString()).apply()
    }

    private fun saveArchives(list: MutableList<AccountingArchive>) {
        val array = JSONArray()
        list.sortedByDescending { it.number }.forEach { archive ->
            val numbers = JSONArray()
            archive.invoiceNumbers.forEach { numbers.put(it) }
            array.put(JSONObject().apply {
                put("number", archive.number)
                put("date", archive.date)
                put("invoiceNumbers", numbers)
            })
        }
        prefs.edit().putString("accountingArchives", array.toString()).apply()
    }

    private fun fromProduct(json: JSONObject): Product {
        val array = json.optJSONArray("history") ?: JSONArray()
        val history = MutableList(array.length()) { i ->
            val item = array.getJSONObject(i)
            PurchaseRecord(item.optString("date"), item.optDouble("price"), item.optString("note"))
        }
        return Product(json.optString("name"), json.optDouble("current"), history)
    }

    private fun fromInvoice(json: JSONObject): Invoice {
        val array = json.optJSONArray("items") ?: JSONArray()
        val items = MutableList(array.length()) { i ->
            val item = array.getJSONObject(i)
            InvoiceItem(
                item.optString("name"),
                item.optDouble("qty"),
                item.optDouble("saleUnit"),
                item.optDouble("saleTotal"),
                item.optDouble("purchase"),
                item.optDouble("partnerPrice")
            )
        }
        return Invoice(
            number = json.optString("number"),
            date = json.optString("date"),
            clientName = json.optString("client"),
            phone = json.optString("phone"),
            city = json.optString("city"),
            address = json.optString("address"),
            trackingNumber = json.optString("trackingNumber"),
            commercial = json.optString("commercial"),
            shipping = json.optDouble("shipping"),
            actualShippingCost = if (json.has("actualShippingCost")) json.optDouble("actualShippingCost") else json.optDouble("shipping"),
            commercialProfit = json.optDouble("commercialProfit"),
            total = json.optDouble("total"),
            originalPdfUri = json.optString("originalPdfUri"),
            deliveryReceived = if (json.has("deliveryReceived")) json.optBoolean("deliveryReceived", true) else true,
            items = items
        )
    }
}
