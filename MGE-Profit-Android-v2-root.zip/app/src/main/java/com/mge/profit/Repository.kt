package com.mge.profit

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Repository(context: Context) {
    private val prefs = context.getSharedPreferences("mge_profit_db", Context.MODE_PRIVATE)

    fun invoices(): MutableList<Invoice> {
        val array = JSONArray(prefs.getString("invoices", "[]"))
        return MutableList(array.length()) { i -> fromInvoice(array.getJSONObject(i)) }
    }

    fun products(): MutableList<Product> {
        val array = JSONArray(prefs.getString("products", "[]"))
        return MutableList(array.length()) { i -> fromProduct(array.getJSONObject(i)) }
    }

    fun findProduct(name: String): Product? = products().firstOrNull {
        it.name.trim().equals(name.trim(), ignoreCase = true)
    }

    fun currentPurchase(name: String): Double = findProduct(name)?.currentPurchasePrice ?: 0.0

    fun savePurchasePrice(name: String, price: Double, note: String = "") {
        val cleanName = name.trim()
        if (cleanName.isBlank()) return
        val list = products()
        val existing = list.firstOrNull { it.name.trim().equals(cleanName, ignoreCase = true) }
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (existing == null) {
            list.add(Product(cleanName, price, mutableListOf(PurchaseRecord(date, price, note))))
        } else {
            existing.currentPurchasePrice = price
            existing.history.add(PurchaseRecord(date, price, note))
        }
        saveProducts(list)
    }

    fun invoiceExists(number: String): Boolean = invoices().any { it.number == number }

    fun saveInvoice(invoice: Invoice) {
        val list = invoices()
        if (list.any { it.number == invoice.number }) {
            throw IllegalArgumentException("الفاتورة رقم ${invoice.number} موجودة مسبقاً.")
        }
        list.add(0, invoice)
        saveInvoices(list)
    }

    fun deleteInvoice(number: String) {
        saveInvoices(invoices().filterNot { it.number == number }.toMutableList())
    }

    fun deleteInvoices(numbers: Set<String>) {
        saveInvoices(invoices().filterNot { numbers.contains(it.number) }.toMutableList())
    }

    private fun saveProducts(list: MutableList<Product>) {
        val array = JSONArray()
        list.forEach { product ->
            val history = JSONArray()
            product.history.forEach { record ->
                history.put(JSONObject().apply {
                    put("date", record.date)
                    put("price", record.price)
                    put("note", record.note)
                })
            }
            array.put(JSONObject().apply {
                put("name", product.name)
                put("current", product.currentPurchasePrice)
                put("history", history)
            })
        }
        prefs.edit().putString("products", array.toString()).apply()
    }

    private fun saveInvoices(list: MutableList<Invoice>) {
        val array = JSONArray()
        list.forEach { invoice ->
            val items = JSONArray()
            invoice.items.forEach { item ->
                items.put(JSONObject().apply {
                    put("name", item.name)
                    put("qty", item.quantity)
                    put("saleUnit", item.saleUnitPrice)
                    put("saleTotal", item.saleTotal)
                    put("purchase", item.purchasePriceAtSale)
                })
            }
            array.put(JSONObject().apply {
                put("number", invoice.number)
                put("date", invoice.date)
                put("client", invoice.clientName)
                put("phone", invoice.phone)
                put("city", invoice.city)
                put("address", invoice.address)
                put("commercial", invoice.commercial)
                put("shipping", invoice.shipping)
                put("commercialProfit", invoice.commercialProfit)
                put("total", invoice.total)
                put("originalPdfUri", invoice.originalPdfUri)
                put("items", items)
            })
        }
        prefs.edit().putString("invoices", array.toString()).apply()
    }

    private fun fromProduct(json: JSONObject): Product {
        val array = json.optJSONArray("history") ?: JSONArray()
        val history = MutableList(array.length()) { i ->
            val item = array.getJSONObject(i)
            PurchaseRecord(item.optString("date"), item.optDouble("price"), item.optString("note"))
        }
        return Product(json.optString("name"), json.optDouble("current"), history)
    }

    private fun fromInvoice(json: JSONObject): Invoice {
        val array = json.optJSONArray("items") ?: JSONArray()
        val items = MutableList(array.length()) { i ->
            val item = array.getJSONObject(i)
            InvoiceItem(
                item.optString("name"),
                item.optDouble("qty"),
                item.optDouble("saleUnit"),
                item.optDouble("saleTotal"),
                item.optDouble("purchase")
            )
        }
        return Invoice(
            number = json.optString("number"),
            date = json.optString("date"),
            clientName = json.optString("client"),
            phone = json.optString("phone"),
            city = json.optString("city"),
            address = json.optString("address"),
            commercial = json.optString("commercial"),
            shipping = json.optDouble("shipping"),
            commercialProfit = json.optDouble("commercialProfit"),
            total = json.optDouble("total"),
            originalPdfUri = json.optString("originalPdfUri"),
            items = items
        )
    }
}
