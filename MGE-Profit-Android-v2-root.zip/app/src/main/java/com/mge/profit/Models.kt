package com.mge.profit

data class InvoiceItem(
    var name: String,
    var quantity: Double,
    var saleUnitPrice: Double,
    var saleTotal: Double,
    var purchasePriceAtSale: Double = 0.0,
    var partnerPriceAtSale: Double = 0.0
) {
    val purchaseTotal: Double get() = quantity * purchasePriceAtSale
    val partnerTotal: Double get() = quantity * partnerPriceAtSale
    val profitBeforeCommercial: Double get() = saleTotal - purchaseTotal
    val netProfit: Double get() = profitBeforeCommercial - partnerTotal
}

data class Invoice(
    var number: String,
    var date: String = "",
    var clientName: String = "",
    var phone: String = "",
    var city: String = "",
    var address: String = "",
    var commercial: String = "",
    var shipping: Double = 0.0,
    var commercialProfit: Double = 0.0,
    var total: Double = 0.0,
    var originalPdfUri: String = "",
    var items: MutableList<InvoiceItem> = mutableListOf()
) {
    val productSales: Double get() = items.sumOf { it.saleTotal }
    val purchaseCost: Double get() = items.sumOf { it.purchaseTotal }
    val grossProfit: Double get() = items.sumOf { it.profitBeforeCommercial }
    val calculatedPartnerProfit: Double get() = items.sumOf { it.partnerTotal }
    val netProfit: Double get() = if (items.any { it.partnerPriceAtSale > 0.0 }) grossProfit - calculatedPartnerProfit else grossProfit - commercialProfit
    val isCommercialInvoice: Boolean get() = commercial.isNotBlank() || commercialProfit > 0.0
}

data class PurchaseRecord(val date: String, val price: Double, val note: String = "")

data class Product(
    var name: String,
    var currentPurchasePrice: Double = 0.0,
    var history: MutableList<PurchaseRecord> = mutableListOf()
)
