package com.mge.profit

data class InvoiceItem(var name:String,var quantity:Double,var saleUnitPrice:Double,var saleTotal:Double,var purchasePriceAtSale:Double=0.0){val purchaseTotal get()=quantity*purchasePriceAtSale; val profit get()=saleTotal-purchaseTotal}
data class Invoice(var number:String,var date:String="",var clientName:String="",var phone:String="",var city:String="",var address:String="",var commercial:String="",var shipping:Double=0.0,var commercialProfit:Double=0.0,var total:Double=0.0,var items:MutableList<InvoiceItem> = mutableListOf()){val productSales get()=items.sumOf{it.saleTotal}; val purchaseCost get()=items.sumOf{it.purchaseTotal}; val netProfit get()=productSales-purchaseCost-commercialProfit}
data class PurchaseRecord(val date:String,val price:Double,val note:String="")
data class Product(var name:String,var currentPurchasePrice:Double=0.0,var history:MutableList<PurchaseRecord> = mutableListOf())
