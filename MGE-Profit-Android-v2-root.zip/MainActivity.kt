package com.mge.profit

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var repo: Repository
    private lateinit var root: LinearLayout

    private val purple = Color.rgb(106, 75, 188)
    private val green = Color.rgb(21, 148, 71)
    private val orange = Color.rgb(232, 138, 18)
    private val red = Color.rgb(215, 58, 73)
    private val bg = Color.rgb(247, 247, 251)
    private val ink = Color.rgb(43, 40, 52)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        repo = Repository(this)
        dashboard()
    }

    private fun text(value: String, size: Number, bold: Boolean = false, color: Int = ink): TextView {
        return TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            gravity = Gravity.RIGHT
            if (bold) setTypeface(typeface, 1)
        }
    }

    private fun base(title: String, subtitle: String = ""): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 18, 20, 10)
        }

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        titleBox.addView(text(title, 25, true))
        if (subtitle.isNotBlank()) {
            titleBox.addView(text(subtitle, 14, false, Color.DKGRAY))
        }

        header.addView(titleBox)
        header.addView(text("▥", 30, true, purple), LinearLayout.LayoutParams(52, 52))
        root.addView(header)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 4, 16, 90)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
            elevation = 8f
        }

        val buttons = listOf(
            "الرئيسية" to { dashboard() },
            "الفواتير" to { invoices() },
            "المنتجات" to { products() },
            "التقارير" to { reports() }
        )
        buttons.forEach { (label, action) ->
            nav.addView(
                Button(this).apply {
                    text = label
                    textSize = 12f
                    setTextColor(purple)
                    setBackgroundColor(Color.TRANSPARENT)
                    setOnClickListener { action() }
                },
                LinearLayout.LayoutParams(0, 58, 1f)
            )
        }
        root.addView(nav)
        setContentView(root)
        return content
    }

    private fun card(view: View): MaterialCardView {
        return MaterialCardView(this).apply {
            radius = 22f
            cardElevation = 2f
            setCardBackgroundColor(Color.WHITE)
            addView(view)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 5, 0, 5)
            }
        }
    }

    private fun money(value: Double): String = String.format(Locale.US, "%.2f DH", value)

    private fun stat(title: String, value: String, color: Int): MaterialCardView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
        }
        box.addView(text(title, 13, false, Color.DKGRAY))
        box.addView(text(value, 19, true, color))
        return card(box)
    }

    private fun dashboard() {
        val content = base("MGE-Profit", "حساب أرباح فواتير MGE")
        val invoices = repo.invoices()
        val grid = GridLayout(this).apply { columnCount = 2 }

        val values = listOf(
            Triple("عدد الفواتير", invoices.size.toString(), purple),
            Triple("إجمالي المبيعات", money(invoices.sumOf { it.productSales }), green),
            Triple("تكلفة المنتجات", money(invoices.sumOf { it.purchaseCost }), orange),
            Triple("أرباح الشركاء", money(invoices.sumOf { it.commercialProfit }), purple),
            Triple("صافي الأرباح", money(invoices.sumOf { it.netProfit }), green),
            Triple("المنتجات", repo.products().size.toString(), orange)
        )

        values.forEach { value ->
            grid.addView(
                stat(value.first, value.second, value.third),
                GridLayout.LayoutParams().apply {
                    width = 0
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(4, 4, 4, 4)
                }
            )
        }
        content.addView(grid)

        content.addView(
            Button(this).apply {
                text = "📄  استيراد فاتورة PDF"
                textSize = 17f
                setTextColor(Color.WHITE)
                setBackgroundColor(purple)
                setOnClickListener { pick() }
            },
            LinearLayout.LayoutParams(-1, 58).apply {
                setMargins(0, 12, 0, 10)
            }
        )

        val recent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
        }
        recent.addView(text("آخر الفواتير", 18, true))

        if (invoices.isEmpty()) {
            recent.addView(text("لم يتم استيراد فواتير بعد.", 14, false, Color.GRAY))
        }

        invoices.take(5).forEach { invoice ->
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(10, 10, 10, 10)
            }
            row.addView(
                text(
                    "#${invoice.number}  ${invoice.date}\n${invoice.clientName.ifBlank { "بدون اسم" }}",
                    14
                ),
                LinearLayout.LayoutParams(0, -2, 1f)
            )
            row.addView(text(money(invoice.netProfit), 15, true, green))
            recent.addView(row)
        }
        content.addView(card(recent))
    }

    private fun invoices() {
        val content = base("الفواتير", "البحث وفتح تفاصيل الفواتير")
        val search = EditText(this).apply {
            hint = "بحث برقم الفاتورة، الزبون أو التجاري"
        }
        content.addView(search, LinearLayout.LayoutParams(-1, 55))

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        fun draw() {
            list.removeAllViews()
            val query = search.text.toString().lowercase(Locale.getDefault())
            repo.invoices()
                .filter { invoice ->
                    query.isBlank() || listOf(
                        invoice.number,
                        invoice.clientName,
                        invoice.commercial,
                        invoice.date
                    ).any { it.lowercase(Locale.getDefault()).contains(query) }
                }
                .forEach { invoice ->
                    val box = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(16, 14, 16, 14)
                    }
                    box.addView(text("#${invoice.number}    ${money(invoice.netProfit)}", 17, true, green))
                    box.addView(
                        text(
                            "${invoice.date} • ${invoice.clientName.ifBlank { "بدون زبون" }} • ${invoice.commercial.ifBlank { "بدون تجاري" }}",
                            13
                        )
                    )
                    box.setOnClickListener { details(invoice) }
                    list.addView(card(box))
                }
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { draw() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        draw()
    }

    private fun products() {
        val content = base("المنتجات", "سعر الشراء الحالي وسجل الأسعار")
        content.addView(
            Button(this).apply {
                text = "＋ إضافة منتج / سعر شراء"
                setTextColor(Color.WHITE)
                setBackgroundColor(purple)
                setOnClickListener { editProduct(null) }
            }
        )

        repo.products()
            .sortedBy { it.name.lowercase(Locale.getDefault()) }
            .forEach { product ->
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(16, 14, 16, 14)
                }
                box.addView(text("${product.name}    ${money(product.currentPurchasePrice)}", 16, true, purple))
                box.addView(text("سجل الأسعار: ${product.history.size} • اضغط للتعديل", 12, false, Color.GRAY))
                box.setOnClickListener { editProduct(product.name) }
                content.addView(card(box))
            }
    }

    private fun editProduct(existing: String?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 10, 30, 0)
        }
        val name = EditText(this).apply {
            hint = "اسم المنتج"
            setText(existing ?: "")
        }
        val price = EditText(this).apply {
            hint = "سعر الشراء"
            inputType = 2
        }
        repo.findProduct(existing ?: "")?.let {
            price.setText(it.currentPurchasePrice.toString())
        }
        box.addView(name)
        box.addView(price)

        MaterialAlertDialogBuilder(this)
            .setTitle("سعر الشراء")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val cleanName = name.text.toString().trim()
                val value = price.text.toString().replace(",", ".").toDoubleOrNull()
                if (cleanName.isNotBlank() && value != null) {
                    repo.savePurchasePrice(cleanName, value, "تعديل يدوي")
                    products()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun reports() {
        val content = base("التقارير", "الربح حسب المنتجات والتجاريين")
        val invoices = repo.invoices()

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
        }
        summary.addView(text("صافي الربح", 14, false, Color.GRAY))
        summary.addView(text(money(invoices.sumOf { it.netProfit }), 28, true, green))
        summary.addView(text("أرباح الشركاء: ${money(invoices.sumOf { it.commercialProfit })}", 14, false, purple))
        content.addView(card(summary))

        val productProfits = linkedMapOf<String, Double>()
        invoices.forEach { invoice ->
            invoice.items.forEach { item ->
                productProfits[item.name] = (productProfits[item.name] ?: 0.0) + item.profit
            }
        }

        val productBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
        }
        productBox.addView(text("أفضل المنتجات حسب الربح", 18, true))
        productProfits.entries
            .sortedByDescending { it.value }
            .take(10)
            .forEachIndexed { index, entry ->
                val color = if (entry.value >= 0.0) green else red
                productBox.addView(
                    text(
                        "${index + 1}. ${entry.key}    ${money(entry.value)}",
                        14,
                        false,
                        color
                    )
                )
            }
        content.addView(card(productBox))
    }

    private fun details(invoice: Invoice) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        box.addView(text("الفاتورة #${invoice.number}", 21, true, purple))
        box.addView(
            text(
                "${invoice.date}\nالزبون: ${invoice.clientName}\nالهاتف: ${invoice.phone}\nالمدينة: ${invoice.city}\nالتجاري: ${invoice.commercial.ifBlank { "-" }}",
                14
            )
        )

        invoice.items.forEach { item ->
            box.addView(
                text(
                    "• ${item.name}\n  ${item.quantity} × ${money(item.saleUnitPrice)} | شراء ${money(item.purchasePriceAtSale)} | ربح ${money(item.profit)}",
                    13
                )
            )
        }

        box.addView(
            text(
                "\nالمبيعات: ${money(invoice.productSales)}\nتكلفة الشراء: ${money(invoice.purchaseCost)}\nربح التجاري: ${money(invoice.commercialProfit)}\nالشحن: ${money(invoice.shipping)}\nصافي الربح: ${money(invoice.netProfit)}",
                15,
                true,
                green
            )
        )

        MaterialAlertDialogBuilder(this)
            .setView(box)
            .setPositiveButton("إغلاق", null)
            .setNegativeButton("حذف") { _, _ ->
                repo.deleteInvoice(invoice.number)
                invoices()
            }
            .show()
    }

    private fun pick() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/pdf"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            },
            700
        )
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with this project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 700 || resultCode != Activity.RESULT_OK || data == null) return

        val uris = mutableListOf<android.net.Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip ->
            for (index in 0 until clip.itemCount) {
                uris.add(clip.getItemAt(index).uri)
            }
        }

        uris.distinct().forEach { uri ->
            try {
                review(PdfInvoiceParser.parse(this, uri, repo))
            } catch (error: Exception) {
                Toast.makeText(
                    this,
                    "تعذر قراءة PDF: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun review(invoice: Invoice) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 8, 22, 0)
        }
        box.addView(text("مراجعة الفاتورة #${invoice.number}", 20, true, purple))
        box.addView(
            text(
                "${invoice.date} • ${invoice.clientName}\nCommercial: ${invoice.commercial.ifBlank { "-" }} • الشحن ${money(invoice.shipping)}",
                14
            )
        )

        val fields = mutableListOf<Pair<InvoiceItem, EditText>>()
        invoice.items.forEach { item ->
            box.addView(text("${item.name} | ${item.quantity} × ${money(item.saleUnitPrice)}", 14, true))
            val edit = EditText(this).apply {
                hint = "سعر الشراء للوحدة"
                inputType = 2
                if (item.purchasePriceAtSale > 0.0) {
                    setText(item.purchasePriceAtSale.toString())
                }
            }
            fields.add(item to edit)
            box.addView(edit)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("تأكيد البيانات")
            .setView(box)
            .setPositiveButton("حفظ الفاتورة") { _, _ ->
                fields.forEach { (item, edit) ->
                    val purchase = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0
                    item.purchasePriceAtSale = purchase
                    if (purchase > 0.0) {
                        repo.savePurchasePrice(item.name, purchase, "من الفاتورة #${invoice.number}")
                    }
                }

                try {
                    repo.saveInvoice(invoice)
                    Toast.makeText(
                        this,
                        "تم حفظ الفاتورة وحفظ أسعار الشراء تاريخياً",
                        Toast.LENGTH_LONG
                    ).show()
                    dashboard()
                } catch (error: Exception) {
                    Toast.makeText(this, error.message ?: "حدث خطأ", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
