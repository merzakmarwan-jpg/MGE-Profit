package com.mge.profit

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var repo: Repository
    private lateinit var content: LinearLayout

    private val purple = Color.rgb(103, 75, 184)
    private val purpleDark = Color.rgb(72, 48, 132)
    private val green = Color.rgb(23, 145, 72)
    private val orange = Color.rgb(224, 137, 18)
    private val red = Color.rgb(211, 62, 72)
    private val ink = Color.rgb(40, 38, 47)
    private val muted = Color.rgb(105, 102, 112)
    private val bg = Color.rgb(247, 246, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        repo = Repository(this)
        dashboard()
    }

    private fun tv(value: String, size: Number, bold: Boolean = false, color: Int = ink): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            if (bold) setTypeface(typeface, 1)
        }

    private fun page(title: String, subtitle: String = ""): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 18, 18, 8)
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        titleBox.addView(tv(title, 25, true))
        if (subtitle.isNotBlank()) titleBox.addView(tv(subtitle, 13, false, muted))
        header.addView(titleBox)
        header.addView(tv("MGE", 16, true, Color.WHITE).apply {
            gravity = Gravity.CENTER
            setBackgroundColor(purple)
        }, LinearLayout.LayoutParams(52, 52))
        root.addView(header)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 6, 14, 90)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNav())
        setContentView(root)
        return content
    }

    private fun bottomNav(): View {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            elevation = 10f
        }
        val items = listOf(
            "الرئيسية" to { dashboard() },
            "الفواتير" to { invoices() },
            "المنتجات" to { products() },
            "التقارير" to { reports() }
        )
        items.forEach { (label, action) ->
            nav.addView(TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(purple)
                setPadding(4, 8, 4, 8)
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, 62, 1f))
        }
        return nav
    }

    private fun card(view: View, radius: Float = 18f): MaterialCardView =
        MaterialCardView(this).apply {
            this.radius = radius
            cardElevation = 1.5f
            strokeWidth = 1
            strokeColor = Color.rgb(228, 225, 234)
            setCardBackgroundColor(Color.WHITE)
            addView(view)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 5, 0, 5)
            }
        }

    private fun money(value: Double): String = String.format(Locale.US, "%.2f DH", value)

    private fun stat(title: String, value: String, color: Int): MaterialCardView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 13, 16, 13)
        }
        box.addView(tv(title, 13, false, muted))
        box.addView(tv(value, 20, true, color))
        return card(box, 16f)
    }

    private fun sectionTitle(title: String): TextView = tv(title, 19, true).apply {
        setPadding(4, 14, 4, 6)
    }

    private fun primaryButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 15f
        setTextColor(Color.WHITE)
        setBackgroundColor(purple)
        setOnClickListener { action() }
        minHeight = 54
    }

    private fun dashboard() {
        val c = page("MGE-Profit", "إدارة أرباح فواتير MGE")
        val invoices = repo.invoices()
        val sales = invoices.sumOf { it.productSales }
        val costs = invoices.sumOf { it.purchaseCost }
        val partner = invoices.sumOf { it.commercialProfit }
        val net = invoices.sumOf { it.netProfit }

        val welcome = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(Color.rgb(242, 238, 252))
        }
        welcome.addView(tv("لوحة التحكم", 14, true, purpleDark))
        welcome.addView(tv("تابع المبيعات والتكاليف والأرباح من مكان واحد", 13, false, muted))
        c.addView(card(welcome, 18f))

        val grid = android.widget.GridLayout(this).apply { columnCount = 2 }
        listOf(
            Triple("عدد الفواتير", invoices.size.toString(), purple),
            Triple("إجمالي المبيعات", money(sales), green),
            Triple("تكلفة المنتجات", money(costs), orange),
            Triple("أرباح الشركاء", money(partner), purple),
            Triple("صافي الأرباح", money(net), green),
            Triple("عدد المنتجات", repo.products().size.toString(), orange)
        ).forEach { s ->
            grid.addView(stat(s.first, s.second, s.third), android.widget.GridLayout.LayoutParams().apply {
                width = 0
                columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f)
                setMargins(4, 4, 4, 4)
            })
        }
        c.addView(grid)

        c.addView(primaryButton("＋  استيراد فاتورة PDF", { pick() }).apply {
            setPadding(8, 0, 8, 0)
        }, LinearLayout.LayoutParams(-1, 56).apply { setMargins(0, 10, 0, 4) })

        c.addView(sectionTitle("آخر الفواتير"))
        if (invoices.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(20, 28, 20, 28)
            }
            empty.addView(tv("لا توجد فواتير بعد", 17, true, muted).apply { gravity = Gravity.CENTER })
            empty.addView(tv("اضغط على استيراد فاتورة PDF للبدء", 13, false, muted).apply { gravity = Gravity.CENTER })
            c.addView(card(empty))
        } else {
            invoices.take(6).forEach { invoice -> invoiceRow(invoice) }
        }
    }

    private fun invoiceRow(invoice: Invoice) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 13, 16, 13)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(tv("فاتورة #${invoice.number}", 16, true, purple), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(tv(money(invoice.netProfit), 16, true, if (invoice.netProfit >= 0) green else red))
        box.addView(top)
        box.addView(tv("${invoice.date}  •  ${invoice.clientName.ifBlank { "بدون اسم" }}", 13, false, muted))
        box.addView(tv("${invoice.items.size} منتجات  •  مبيعات ${money(invoice.productSales)}", 12, false, muted))
        box.setOnClickListener { details(invoice) }
        content.addView(card(box))
    }

    private fun invoices() {
        val c = page("الفواتير", "البحث وعرض تفاصيل كل فاتورة")
        val search = EditText(this).apply {
            hint = "ابحث برقم الفاتورة أو الزبون أو التجاري أو التاريخ"
            setSingleLine(true)
            setPadding(18, 0, 18, 0)
            background = null
        }
        c.addView(card(search, 14f), LinearLayout.LayoutParams(-1, 54))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(list)

        fun draw() {
            list.removeAllViews()
            val q = search.text.toString().trim().lowercase(Locale.getDefault())
            repo.invoices().filter { inv ->
                q.isBlank() || listOf(inv.number, inv.clientName, inv.commercial, inv.date).any {
                    it.lowercase(Locale.getDefault()).contains(q)
                }
            }.forEach { inv ->
                val old = content
                content = list
                invoiceRow(inv)
                content = old
            }
            if (list.childCount == 0) list.addView(tv("لا توجد نتائج", 15, false, muted).apply {
                gravity = Gravity.CENTER
                setPadding(10, 30, 10, 30)
            })
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = draw()
            override fun afterTextChanged(s: Editable?) = Unit
        })
        draw()
    }

    private fun products() {
        val c = page("المنتجات", "أسعار الشراء الحالية وسجل التغييرات")
        c.addView(primaryButton("＋  إضافة منتج وسعر شراء", { editProduct(null) }), LinearLayout.LayoutParams(-1, 54))
        val products = repo.products().sortedBy { it.name.lowercase(Locale.getDefault()) }
        if (products.isEmpty()) {
            c.addView(tv("لم تتم إضافة منتجات بعد", 15, false, muted).apply {
                gravity = Gravity.CENTER
                setPadding(10, 30, 10, 30)
            })
        }
        products.forEach { product ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 14, 16, 14)
            }
            box.addView(tv(product.name, 16, true))
            box.addView(tv("سعر الشراء الحالي  ${money(product.currentPurchasePrice)}", 14, true, purple))
            box.addView(tv("سجل الأسعار: ${product.history.size}  •  اضغط للتعديل", 12, false, muted))
            box.setOnClickListener { editProduct(product.name) }
            c.addView(card(box))
        }
    }

    private fun editProduct(existing: String?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 4, 24, 0)
        }
        val name = EditText(this).apply { hint = "اسم المنتج"; setText(existing ?: "") }
        val price = EditText(this).apply { hint = "سعر الشراء للوحدة"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        repo.findProduct(existing ?: "")?.let { price.setText(it.currentPurchasePrice.toString()) }
        box.addView(name)
        box.addView(price)
        MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "إضافة منتج" else "تعديل سعر الشراء")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                val p = price.text.toString().replace(",", ".").toDoubleOrNull()
                if (n.isBlank() || p == null) {
                    Toast.makeText(this, "أدخل اسم المنتج والسعر بشكل صحيح", Toast.LENGTH_LONG).show()
                } else {
                    repo.savePurchasePrice(n, p, "تعديل يدوي")
                    products()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun reports() {
        val c = page("التقارير", "تحليل الأرباح حسب المنتج والتجاري")
        val inv = repo.invoices()
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
        }
        summary.addView(tv("صافي الأرباح", 14, false, muted))
        summary.addView(tv(money(inv.sumOf { it.netProfit }), 30, true, green))
        summary.addView(tv("المبيعات ${money(inv.sumOf { it.productSales })}  •  التكلفة ${money(inv.sumOf { it.purchaseCost })}", 13, false, muted))
        summary.addView(tv("أرباح الشركاء ${money(inv.sumOf { it.commercialProfit })}", 13, false, purple))
        c.addView(card(summary, 18f))

        val productProfits = linkedMapOf<String, Double>()
        inv.forEach { invoice -> invoice.items.forEach { item -> productProfits[item.name] = (productProfits[item.name] ?: 0.0) + item.profit } }
        c.addView(sectionTitle("الربح حسب المنتج"))
        productProfits.entries.sortedByDescending { it.value }.take(20).forEachIndexed { index, e ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(15, 12, 15, 12)
            }
            box.addView(tv("${index + 1}. ${e.key}", 14, false), LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(tv(money(e.value), 14, true, if (e.value >= 0) green else red))
            c.addView(card(box, 14f))
        }

        val commercialProfits = linkedMapOf<String, Double>()
        inv.filter { it.commercial.isNotBlank() }.forEach { commercialProfits[it.commercial] = (commercialProfits[it.commercial] ?: 0.0) + it.commercialProfit }
        c.addView(sectionTitle("أرباح التجاريين"))
        if (commercialProfits.isEmpty()) c.addView(tv("لا توجد فواتير مرتبطة بتجاريين", 14, false, muted))
        commercialProfits.entries.sortedByDescending { it.value }.forEach { e ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(15, 12, 15, 12) }
            box.addView(tv(e.key, 14, true), LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(tv(money(e.value), 14, true, purple))
            c.addView(card(box, 14f))
        }
    }

    private fun details(invoice: Invoice) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 6, 20, 0)
        }
        box.addView(tv("فاتورة #${invoice.number}", 21, true, purple))
        box.addView(tv("${invoice.date}\nالزبون: ${invoice.clientName.ifBlank { "-" }}\nالهاتف: ${invoice.phone.ifBlank { "-" }}\nالمدينة: ${invoice.city.ifBlank { "-" }}\nالتجاري: ${invoice.commercial.ifBlank { "-" }}", 14))
        box.addView(tv("المنتجات", 16, true).apply { setPadding(0, 14, 0, 6) })
        invoice.items.forEach { item ->
            box.addView(tv("${item.name}\n${item.quantity} × ${money(item.saleUnitPrice)} = ${money(item.saleTotal)}\nشراء ${money(item.purchasePriceAtSale)}  •  ربح ${money(item.profit)}", 13).apply {
                setPadding(0, 5, 0, 5)
            })
        }
        box.addView(tv("\nالمبيعات: ${money(invoice.productSales)}\nتكلفة الشراء: ${money(invoice.purchaseCost)}\nربح التجاري: ${money(invoice.commercialProfit)}\nالشحن: ${money(invoice.shipping)}\nصافي الربح: ${money(invoice.netProfit)}", 15, true, green))
        MaterialAlertDialogBuilder(this)
            .setTitle("تفاصيل الفاتورة")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("إغلاق", null)
            .setNegativeButton("حذف") { _, _ -> repo.deleteInvoice(invoice.number); invoices() }
            .show()
    }

    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }, 700)
    }

    @Deprecated("Deprecated Android API; retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 700 || resultCode != Activity.RESULT_OK || data == null) return
        val uris = mutableListOf<android.net.Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        uris.distinct().forEach { uri ->
            try { review(PdfInvoiceParser.parse(this, uri, repo)) }
            catch (e: Exception) { Toast.makeText(this, "تعذر قراءة PDF: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun review(invoice: Invoice) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 6, 20, 10)
        }
        box.addView(tv("مراجعة الفاتورة #${invoice.number}", 20, true, purple))
        box.addView(tv("${invoice.date}  •  ${invoice.clientName.ifBlank { "بدون اسم" }}\n${invoice.items.size} منتجات  •  إجمالي ${money(invoice.total)}", 14))
        if (invoice.items.isEmpty()) box.addView(tv("⚠ لم يتم التعرف على المنتجات. راجع ملف PDF قبل الحفظ.", 14, true, red).apply { setPadding(0, 12, 0, 8) })
        val fields = mutableListOf<Pair<InvoiceItem, EditText>>()
        invoice.items.forEach { item ->
            box.addView(tv("${item.name}\n${item.quantity} × ${money(item.saleUnitPrice)} = ${money(item.saleTotal)}", 14, true).apply { setPadding(0, 7, 0, 2) })
            val edit = EditText(this).apply {
                hint = "سعر الشراء للوحدة"
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                if (item.purchasePriceAtSale > 0) setText(item.purchasePriceAtSale.toString())
            }
            fields.add(item to edit)
            box.addView(edit)
        }
        scroll.addView(box)
        MaterialAlertDialogBuilder(this)
            .setTitle("تأكيد بيانات الفاتورة")
            .setView(scroll)
            .setPositiveButton("حفظ الفاتورة") { _, _ ->
                fields.forEach { (item, edit) ->
                    val p = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0
                    item.purchasePriceAtSale = p
                    if (p > 0) repo.savePurchasePrice(item.name, p, "من الفاتورة #${invoice.number}")
                }
                try {
                    repo.saveInvoice(invoice)
                    Toast.makeText(this, "تم حفظ الفاتورة مع تثبيت سعر الشراء التاريخي", Toast.LENGTH_LONG).show()
                    dashboard()
                } catch (e: Exception) {
                    Toast.makeText(this, e.message ?: "حدث خطأ", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
