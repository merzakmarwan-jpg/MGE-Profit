package com.mge.profit

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.StaticLayout
import android.text.Layout
import android.text.TextPaint
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var repo: Repository
    private lateinit var content: LinearLayout
    private var selectionMode = false
    private val selected = linkedSetOf<String>()
    private var filterType = 0 // 0 all, 1 admin, 2 commercial
    private var filterDate = ""
    private var filterCommercial = ""
    private val pendingImports = mutableListOf<Uri>()
    private var pendingIndex = 0

    private val primary = Color.rgb(84, 62, 160)
    private val primaryDark = Color.rgb(57, 40, 112)
    private val accent = Color.rgb(25, 139, 76)
    private val warning = Color.rgb(225, 137, 15)
    private val danger = Color.rgb(205, 58, 70)
    private val blue = Color.rgb(37, 104, 170)
    private val ink = Color.rgb(35, 34, 41)
    private val muted = Color.rgb(105, 101, 113)
    private val bg = Color.rgb(247, 246, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        repo = Repository(this)
        dashboard()
    }

    private fun tv(value: String, size: Number, bold: Boolean = false, color: Int = ink): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            if (bold) setTypeface(typeface, 1)
        }

    private fun page(title: String, subtitle: String = "", showNav: Boolean = true): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 16, 18, 10)
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        titleBox.addView(tv(title, 25, true))
        if (subtitle.isNotBlank()) titleBox.addView(tv(subtitle, 13, false, muted))
        header.addView(titleBox)
        header.addView(TextView(this).apply {
            text = "MGE\nPROFIT"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(typeface, 1)
            setBackgroundColor(primary)
        }, LinearLayout.LayoutParams(62, 54))
        root.addView(header)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 4, 14, if (showNav) 10 else 22)
        }
        val scroll = ScrollView(this)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (showNav) root.addView(bottomNav())
        setContentView(root)
        return content
    }

    private fun bottomNav(): View {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            elevation = 12f
        }
        val items = listOf(
            "⌂\nالرئيسية" to { dashboard() },
            "▤\nالفواتير" to { invoices() },
            "▦\nالمنتجات" to { products() },
            "▥\nالتقارير" to { reports() },
            "⚙\nالإعدادات" to { settings() }
        )
        items.forEach { (label, action) ->
            nav.addView(TextView(this).apply {
                text = label
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(primary)
                setPadding(2, 5, 2, 5)
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, 66, 1f))
        }
        return nav
    }

    private fun card(view: View, radius: Float = 18f): MaterialCardView = MaterialCardView(this).apply {
        this.radius = radius
        cardElevation = 1.5f
        strokeWidth = 1
        strokeColor = Color.rgb(228, 225, 234)
        setCardBackgroundColor(Color.WHITE)
        addView(view)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) }
    }

    private fun money(value: Double): String = String.format(Locale.US, "%.2f DH", value)

    private fun button(label: String, action: () -> Unit, filled: Boolean = true): Button = Button(this).apply {
        text = label
        textSize = 14f
        setOnClickListener { action() }
        minHeight = 52
        if (filled) {
            setTextColor(Color.WHITE)
            setBackgroundColor(primary)
        } else {
            setTextColor(primary)
            setBackgroundColor(Color.WHITE)
        }
    }

    private fun section(title: String, subtitle: String = "") {
        content.addView(tv(title, 19, true).apply { setPadding(4, 15, 4, 4) })
        if (subtitle.isNotBlank()) content.addView(tv(subtitle, 12, false, muted).apply { setPadding(4, 0, 4, 7) })
    }

    private fun dashboard() {
        val c = page("MGE-Profit", "إدارة أرباح فواتير MGE")
        val inv = repo.invoices()
        val sales = inv.sumOf { it.productSales }
        val cost = inv.sumOf { it.purchaseCost }
        val partner = inv.sumOf { it.commercialProfit }
        val net = inv.sumOf { it.netProfit }

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(239, 235, 249))
        }
        hero.addView(tv("لوحة التحكم", 16, true, primaryDark))
        hero.addView(tv("ملخص سريع للمبيعات والتكلفة وأرباح الشركاء وصافي الربح", 13, false, muted))
        c.addView(card(hero))

        val grid = GridLayout(this).apply { columnCount = 2 }
        listOf(
            "الفواتير" to inv.size.toString() to primary,
            "المبيعات" to money(sales) to accent,
            "تكلفة الشراء" to money(cost) to warning,
            "أرباح الشركاء" to money(partner) to blue,
            "صافي الربح" to money(net) to accent,
            "المنتجات" to repo.products().size.toString() to warning
        ).forEach { item ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(15, 13, 15, 13) }
            box.addView(tv(item.first.first, 13, false, muted))
            box.addView(tv(item.first.second, 19, true, item.second))
            grid.addView(card(box, 15f), GridLayout.LayoutParams().apply {
                width = 0; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(4, 4, 4, 4)
            })
        }
        c.addView(grid)
        c.addView(button("＋  جلب فواتير PDF جديدة", { pickPdfs() }).apply {
            setPadding(6, 0, 6, 0)
        }, LinearLayout.LayoutParams(-1, 56).apply { setMargins(0, 12, 0, 4) })

        section("آخر الفواتير", "اضغط على أي فاتورة لفتح تفاصيلها")
        inv.take(5).forEach { invoiceCard(it, false) }
        if (inv.isEmpty()) c.addView(emptyState("لا توجد فواتير بعد", "ابدأ بجلب ملفات PDF الخاصة بفواتير MGE"))
    }

    private fun emptyState(title: String, subtitle: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(20, 28, 20, 28) }
        box.addView(tv(title, 17, true, muted).apply { gravity = Gravity.CENTER })
        box.addView(tv(subtitle, 13, false, muted).apply { gravity = Gravity.CENTER })
        return card(box)
    }

    private fun invoices() {
        val c = page("الفواتير", "إدارة واستدعاء فواتير MGE")
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        toolbar.addView(button("⚙ فلترة", { filterDialog() }, false), LinearLayout.LayoutParams(0, 52, 1f).apply { setMargins(2, 2, 2, 2) })
        toolbar.addView(button(if (selectionMode) "✓ إلغاء التحديد" else "☑ تحديد الفواتير", { toggleSelection() }, false), LinearLayout.LayoutParams(0, 52, 1f).apply { setMargins(2, 2, 2, 2) })
        toolbar.addView(button("＋ جلب الجديدة", { pickPdfs() }), LinearLayout.LayoutParams(0, 52, 1f).apply { setMargins(2, 2, 2, 2) })
        c.addView(toolbar)

        if (selectionMode) {
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(button("تحديد الكل", { repo.invoices().forEach { selected.add(it.number) }; invoices() }, false), LinearLayout.LayoutParams(0, 48, 1f))
            actions.addView(button("حذف المحدد", { confirmDeleteSelected() }, false), LinearLayout.LayoutParams(0, 48, 1f))
            actions.addView(button("PDF هامش الربح", { shareSelectedMargin() }, false), LinearLayout.LayoutParams(0, 48, 1f))
            c.addView(actions)
        }

        val search = EditText(this).apply {
            hint = "بحث: رقم الفاتورة، الزبون، التجاري، التاريخ"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(18, 0, 18, 0)
        }
        c.addView(card(search, 14f), LinearLayout.LayoutParams(-1, 56))
        val info = tv("${filteredInvoices().size} فاتورة ظاهرة", 12, false, muted).apply { setPadding(5, 8, 5, 4) }
        c.addView(info)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(list)

        fun draw() {
            list.removeAllViews()
            val q = search.text.toString().trim().lowercase(Locale.getDefault())
            val data = filteredInvoices().filter { inv ->
                q.isBlank() || listOf(inv.number, inv.clientName, inv.commercial, inv.date, inv.city, inv.address).any {
                    it.lowercase(Locale.getDefault()).contains(q)
                }
            }
            info.text = "${data.size} فاتورة ظاهرة"
            data.forEach { inv -> invoiceCard(inv, selectionMode, list) }
            if (data.isEmpty()) list.addView(emptyState("لا توجد نتائج", "غيّر البحث أو الفلترة"))
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { draw() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        draw()
    }

    private fun filteredInvoices(): List<Invoice> = repo.invoices().filter { inv ->
        val typeOk = when (filterType) { 1 -> !inv.isCommercialInvoice; 2 -> inv.isCommercialInvoice; else -> true }
        val dateOk = filterDate.isBlank() || inv.date.contains(filterDate, true)
        val commOk = filterCommercial.isBlank() || inv.commercial.contains(filterCommercial, true)
        typeOk && dateOk && commOk
    }

    private fun invoiceCard(invoice: Invoice, selectable: Boolean, target: LinearLayout = content) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 13, 16, 13) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (selectable) {
            val cb = CheckBox(this).apply {
                isChecked = selected.contains(invoice.number)
                setOnCheckedChangeListener { _, checked -> if (checked) selected.add(invoice.number) else selected.remove(invoice.number) }
            }
            top.addView(cb, LinearLayout.LayoutParams(48, 48))
        }
        top.addView(tv("#${invoice.number}", 21, true, primary), LinearLayout.LayoutParams(0, 48, 1f))
        top.addView(tv(money(invoice.netProfit), 16, true, if (invoice.netProfit >= 0) accent else danger))
        box.addView(top)
        box.addView(tv(invoice.clientName.ifBlank { "بدون اسم زبون" }, 16, true))
        box.addView(tv("${invoice.date}   •   ${if (invoice.isCommercialInvoice) "شريك: ${invoice.commercial}" else "فاتورة مباشرة"}", 13, false, muted))
        box.addView(tv("المبيعات ${money(invoice.productSales)}   •   الشحن ${money(invoice.shipping)}   •   المنتجات ${invoice.items.size}", 12, false, muted))
        if (invoice.isCommercialInvoice) box.addView(tv("ربح الشريك: ${money(invoice.commercialProfit)}", 12, true, blue))
        box.setOnClickListener { if (selectionMode) { if (selected.contains(invoice.number)) selected.remove(invoice.number) else selected.add(invoice.number); invoices() } else details(invoice) }
        target.addView(card(box))
    }

    private fun filterDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 4, 18, 0) }
        val radio = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val all = RadioButton(this).apply { text = "كل الفواتير"; id = 1 }
        val admin = RadioButton(this).apply { text = "فواتير الأدمن / مباشرة"; id = 2 }
        val commercial = RadioButton(this).apply { text = "فواتير الشركاء"; id = 3 }
        radio.addView(all); radio.addView(admin); radio.addView(commercial)
        when (filterType) { 1 -> radio.check(2); 2 -> radio.check(3); else -> radio.check(1) }
        val date = EditText(this).apply { hint = "التاريخ (مثال 03/09/2026)"; setText(filterDate); setSingleLine(true) }
        val comm = EditText(this).apply { hint = "اسم الشريك"; setText(filterCommercial); setSingleLine(true) }
        box.addView(tv("نوع الفاتورة", 15, true, primary)); box.addView(radio); box.addView(date); box.addView(comm)
        MaterialAlertDialogBuilder(this).setTitle("فلترة الفواتير").setView(box)
            .setPositiveButton("تطبيق") { _, _ ->
                filterType = when (radio.checkedRadioButtonId) { 2 -> 1; 3 -> 2; else -> 0 }
                filterDate = date.text.toString().trim(); filterCommercial = comm.text.toString().trim(); invoices()
            }.setNegativeButton("إلغاء", null).setNeutralButton("مسح الفلترة") { _, _ ->
                filterType = 0; filterDate = ""; filterCommercial = ""; invoices()
            }.show()
    }

    private fun toggleSelection() {
        selectionMode = !selectionMode
        if (!selectionMode) selected.clear()
        invoices()
    }

    private fun confirmDeleteSelected() {
        if (selected.isEmpty()) { Toast.makeText(this, "لم تحدد أي فاتورة", Toast.LENGTH_SHORT).show(); return }
        MaterialAlertDialogBuilder(this).setTitle("حذف الفواتير")
            .setMessage("سيتم حذف ${selected.size} فاتورة. هل أنت متأكد؟")
            .setPositiveButton("حذف") { _, _ -> repo.deleteInvoices(selected); selected.clear(); selectionMode = false; invoices() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun products() {
        val c = page("المنتجات", "أسعار الشراء الحالية + التاريخ الكامل لكل تغيير")
        c.addView(button("＋ إضافة منتج / سعر شراء", { editProduct(null) }), LinearLayout.LayoutParams(-1, 54))
        val search = EditText(this).apply { hint = "بحث عن منتج"; setSingleLine(true) }
        c.addView(search, LinearLayout.LayoutParams(-1, 52))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(list)
        fun draw() {
            list.removeAllViews(); val q = search.text.toString().trim().lowercase(Locale.getDefault())
            repo.products().sortedBy { it.name.lowercase(Locale.getDefault()) }.filter { q.isBlank() || it.name.lowercase(Locale.getDefault()).contains(q) }.forEach { p ->
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14) }
                box.addView(tv(p.name, 16, true))
                box.addView(tv("سعر الشراء الحالي: ${money(p.currentPurchasePrice)}", 16, true, primary))
                box.addView(tv("سجل الأسعار: ${p.history.size}   •   اضغط لعرض السجل والتعديل", 12, false, muted))
                box.setOnClickListener { productHistory(p.name) }
                list.addView(card(box))
            }
            if (list.childCount == 0) list.addView(emptyState("لا توجد منتجات", "أضف المنتجات وأسعار الشراء الخاصة بها"))
        }
        search.addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, d: Int)=Unit; override fun onTextChanged(s: CharSequence?,a:Int,b:Int,d:Int){draw()}; override fun afterTextChanged(s: Editable?)=Unit })
        draw()
    }

    private fun editProduct(existing: String?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 0, 22, 0) }
        val name = EditText(this).apply { hint = "اسم المنتج"; setText(existing ?: ""); setSingleLine(true) }
        val price = EditText(this).apply { hint = "سعر الشراء للوحدة (DH)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        repo.findProduct(existing ?: "")?.let { price.setText(it.currentPurchasePrice.toString()) }
        box.addView(name); box.addView(price)
        MaterialAlertDialogBuilder(this).setTitle(if (existing == null) "إضافة منتج" else "تعديل سعر الشراء").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim(); val p = price.text.toString().replace(",", ".").toDoubleOrNull()
                if (n.isBlank() || p == null) Toast.makeText(this, "أدخل الاسم والسعر بشكل صحيح", Toast.LENGTH_LONG).show()
                else { repo.savePurchasePrice(n, p, if (existing == null) "إضافة" else "تعديل يدوي"); products() }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun productHistory(name: String) {
        val p = repo.findProduct(name) ?: return
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 0, 20, 10) }
        box.addView(tv(name, 19, true, primary))
        box.addView(tv("السعر الحالي: ${money(p.currentPurchasePrice)}", 16, true, accent))
        p.history.asReversed().forEach { r -> box.addView(tv("${r.date}   •   ${money(r.price)}\n${r.note}", 13, false, muted).apply { setPadding(0, 8, 0, 8) }) }
        MaterialAlertDialogBuilder(this).setTitle("سجل سعر الشراء").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("تعديل السعر") { _, _ -> editProduct(name) }.setNegativeButton("إغلاق", null).show()
    }

    private fun reports() {
        val c = page("التقارير", "الأرباح الفعلية بعد خصم تكلفة الشراء وربح الشريك")
        val inv = repo.invoices()
        val gross = inv.sumOf { it.grossProfit }
        val partner = inv.sumOf { it.commercialProfit }
        val net = inv.sumOf { it.netProfit }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16) }
        box.addView(tv("إجمالي المبيعات: ${money(inv.sumOf { it.productSales })}", 14, false, muted))
        box.addView(tv("تكلفة الشراء: ${money(inv.sumOf { it.purchaseCost })}", 14, false, muted))
        box.addView(tv("هامش الربح قبل الشريك: ${money(gross)}", 16, true, primary))
        box.addView(tv("ربح الشركاء: ${money(partner)}", 14, true, blue))
        box.addView(tv("صافي ربح MGE: ${money(net)}", 24, true, if (net >= 0) accent else danger))
        c.addView(card(box))

        section("الربح حسب المنتج")
        val productMap = linkedMapOf<String, Double>()
        inv.forEach { i -> i.items.forEach { item -> productMap[item.name] = (productMap[item.name] ?: 0.0) + item.profitBeforeCommercial } }
        productMap.entries.sortedByDescending { it.value }.forEachIndexed { idx, e ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(15, 12, 15, 12) }
            row.addView(tv("${idx + 1}. ${e.key}", 14), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tv(money(e.value), 14, true, if (e.value >= 0) accent else danger)); c.addView(card(row, 14f))
        }

        section("أرباح الشركاء")
        val commercialMap = linkedMapOf<String, Double>()
        inv.filter { it.commercial.isNotBlank() }.forEach { commercialMap[it.commercial] = (commercialMap[it.commercial] ?: 0.0) + it.commercialProfit }
        if (commercialMap.isEmpty()) c.addView(tv("لا توجد فواتير شركاء بعد", 14, false, muted))
        commercialMap.entries.sortedByDescending { it.value }.forEach { e ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(15, 12, 15, 12) }
            row.addView(tv(e.key, 15, true), LinearLayout.LayoutParams(0, -2, 1f)); row.addView(tv(money(e.value), 15, true, blue)); c.addView(card(row, 14f))
        }
    }

    private fun settings() {
        val c = page("الإعدادات", "إعدادات MGE-Profit والبيانات المحلية")
        c.addView(card(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16) }.also {
            it.addView(tv("قاعدة البيانات", 17, true, primary)); it.addView(tv("يتم حفظ الفواتير وأسعار الشراء محلياً على الهاتف.", 13, false, muted)); it.addView(tv("سعر الشراء المثبت داخل كل فاتورة لا يتغير عند تعديل السعر الحالي للمنتج.", 13, true, accent))
        }))
        c.addView(card(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16) }.also {
            it.addView(tv("استيراد الفواتير", 17, true, primary)); it.addView(tv("الفاتورة التي تحمل نفس الرقم لا يتم إدخالها مرة ثانية، وسيظهر تنبيه بأنها موجودة مسبقاً.", 13, false, muted))
        }))
        c.addView(card(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16) }.also {
            it.addView(tv("MGE-Profit", 20, true)); it.addView(tv("نسخة مستقلة لحساب أرباح فواتير MGE", 13, false, muted)); it.addView(tv("النسخة المحلية • بدون الاعتماد على برنامج MGE الأصلي", 12, false, muted))
        }))
    }

    private fun details(invoice: Invoice) {
        val c = page("فاتورة #${invoice.number}", "تفاصيل الفاتورة والربح", false)
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 15, 18, 15) }
        head.addView(tv(invoice.clientName.ifBlank { "بدون اسم" }, 20, true))
        head.addView(tv("التاريخ: ${invoice.date}", 13, false, muted))
        head.addView(tv("الهاتف: ${invoice.phone.ifBlank { "-" }}", 13, false, muted))
        head.addView(tv("المدينة: ${invoice.city.ifBlank { "-" }}", 13, false, muted))
        head.addView(tv("العنوان: ${invoice.address.ifBlank { "-" }}", 13, false, muted))
        head.addView(tv("نوع الفاتورة: ${if (invoice.isCommercialInvoice) "شريك / Commercial: ${invoice.commercial}" else "أدمن / مباشرة"}", 14, true, blue))
        c.addView(card(head))

        section("المنتجات", "سعر البيع + سعر الشراء المثبت وقت استدعاء الفاتورة")
        invoice.items.forEach { item ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(15, 12, 15, 12) }
            row.addView(tv(item.name, 15, true))
            row.addView(tv("الكمية: ${fmtQty(item.quantity)}   •   سعر البيع: ${money(item.saleUnitPrice)}", 13, false, muted))
            row.addView(tv("سعر الشراء: ${money(item.purchasePriceAtSale)}   •   إجمالي الشراء: ${money(item.purchaseTotal)}", 13, false, primary))
            row.addView(tv("هامش المنتج: ${money(item.profitBeforeCommercial)}", 13, true, if (item.profitBeforeCommercial >= 0) accent else danger))
            c.addView(card(row, 14f))
        }

        val sum = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16) }
        sum.addView(tv("المبيعات: ${money(invoice.productSales)}", 14))
        sum.addView(tv("تكلفة الشراء: ${money(invoice.purchaseCost)}", 14))
        sum.addView(tv("هامش الربح قبل الشريك: ${money(invoice.grossProfit)}", 15, true, primary))
        if (invoice.isCommercialInvoice) sum.addView(tv("ربح الشريك: ${money(invoice.commercialProfit)}", 14, true, blue))
        sum.addView(tv("الشحن: ${money(invoice.shipping)}", 14, false, muted))
        sum.addView(tv("صافي ربح MGE: ${money(invoice.netProfit)}", 22, true, if (invoice.netProfit >= 0) accent else danger))
        c.addView(card(sum))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("📄 مشاركة PDF الأصلي", { shareOriginal(invoice) }), LinearLayout.LayoutParams(0, 54, 1f))
        actions.addView(button("📊 PDF هامش الربح", { shareMargin(invoice) }, false), LinearLayout.LayoutParams(0, 54, 1f))
        c.addView(actions)
        c.addView(button("🗑 حذف الفاتورة", { confirmDelete(invoice) }, false), LinearLayout.LayoutParams(-1, 54))
    }

    private fun confirmDelete(invoice: Invoice) {
        MaterialAlertDialogBuilder(this).setTitle("حذف الفاتورة #${invoice.number}")
            .setMessage("سيتم حذف الفاتورة من التطبيق فقط.").setPositiveButton("حذف") { _, _ -> repo.deleteInvoice(invoice.number); invoices() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun pickPdfs() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, 700)
    }

    @Deprecated("Deprecated Android API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 700 || resultCode != Activity.RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        uris.distinct().forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        }
        pendingImports.clear(); pendingImports.addAll(uris.distinct()); pendingIndex = 0
        importNext()
    }

    private fun importNext() {
        if (pendingIndex >= pendingImports.size) { pendingImports.clear(); pendingIndex = 0; invoices(); return }
        val uri = pendingImports[pendingIndex]
        try {
            val parsed = PdfInvoiceParser.parse(this, uri, repo)
            if (repo.invoiceExists(parsed.number)) {
                MaterialAlertDialogBuilder(this).setTitle("الفاتورة موجودة مسبقاً")
                    .setMessage("الفاتورة رقم #${parsed.number} تم استدعاؤها من قبل، لذلك لن يتم إدخالها مرة أخرى.")
                    .setPositiveButton("التالي") { _, _ -> pendingIndex++; importNext() }.show()
            } else review(parsed)
        } catch (e: Exception) {
            MaterialAlertDialogBuilder(this).setTitle("تعذر قراءة الفاتورة")
                .setMessage("الملف لم تتم قراءته بشكل صحيح.\n\n${e.message ?: "خطأ غير معروف"}")
                .setPositiveButton("التالي") { _, _ -> pendingIndex++; importNext() }.setNegativeButton("إيقاف", null).show()
        }
    }

    private fun review(invoice: Invoice) {
        val c = page("مراجعة الفاتورة #${invoice.number}", "تمت قراءة PDF — راجع البيانات قبل الحفظ", false)
        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 15, 18, 15) }
        summary.addView(tv(invoice.clientName.ifBlank { "بدون اسم" }, 20, true))
        summary.addView(tv("${invoice.date}   •   ${invoice.items.size} منتجات", 13, false, muted))
        summary.addView(tv("إجمالي الفاتورة: ${money(invoice.total)}   •   الشحن: ${money(invoice.shipping)}", 14, true, primary))
        if (invoice.isCommercialInvoice) summary.addView(tv("Commercial: ${invoice.commercial}   •   ربح الشريك: ${money(invoice.commercialProfit)}", 14, true, blue))
        c.addView(card(summary))

        if (invoice.items.isEmpty()) c.addView(tv("⚠ لم يتم التعرف على أي منتج. لا تحفظ الفاتورة قبل التأكد من ملف PDF.", 14, true, danger).apply { setPadding(5, 12, 5, 8) })
        val fields = mutableListOf<Pair<InvoiceItem, EditText>>()
        section("أسعار الشراء", "السعر الحالي من قاعدة المنتجات سيُثبت داخل هذه الفاتورة كتاريخي")
        invoice.items.forEach { item ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 11, 14, 11) }
            row.addView(tv(item.name, 15, true))
            row.addView(tv("الكمية ${fmtQty(item.quantity)} × بيع ${money(item.saleUnitPrice)} = ${money(item.saleTotal)}", 13, false, muted))
            val edit = EditText(this).apply {
                hint = "سعر الشراء للوحدة"
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setSingleLine(true)
                if (item.purchasePriceAtSale > 0) setText(item.purchasePriceAtSale.toString())
            }
            fields.add(item to edit); row.addView(edit); c.addView(card(row, 14f))
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("إلغاء", { pendingIndex++; importNext() }, false), LinearLayout.LayoutParams(0, 56, 1f))
        actions.addView(button("✓ حفظ الفاتورة", {
            fields.forEach { (item, edit) ->
                val p = edit.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0
                item.purchasePriceAtSale = p
            }
            try {
                fields.filter { it.first.purchasePriceAtSale > 0 }.forEach { repo.savePurchasePrice(it.first.name, it.first.purchasePriceAtSale, "من الفاتورة #${invoice.number}") }
                repo.saveInvoice(invoice)
                Toast.makeText(this, "تم حفظ الفاتورة #${invoice.number} بنجاح", Toast.LENGTH_LONG).show()
                pendingIndex++; importNext()
            } catch (e: Exception) { Toast.makeText(this, e.message ?: "تعذر الحفظ", Toast.LENGTH_LONG).show() }
        }), LinearLayout.LayoutParams(0, 56, 1f))
        c.addView(actions)
    }

    private fun fmtQty(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else String.format(Locale.US, "%.2f", v)

    private fun shareOriginal(invoice: Invoice) {
        if (invoice.originalPdfUri.isBlank()) { Toast.makeText(this, "لا يوجد ملف PDF أصلي محفوظ لهذه الفاتورة", Toast.LENGTH_LONG).show(); return }
        try {
            val intent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, Uri.parse(invoice.originalPdfUri)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent.createChooser(intent, "مشاركة PDF الأصلي"))
        } catch (e: Exception) { Toast.makeText(this, "تعذر مشاركة الملف", Toast.LENGTH_LONG).show() }
    }

    private fun shareMargin(invoice: Invoice) { shareFile(createMarginPdf(listOf(invoice)), "PDF هامش الربح") }

    private fun shareSelectedMargin() {
        if (selected.isEmpty()) { Toast.makeText(this, "حدد فاتورة واحدة على الأقل", Toast.LENGTH_SHORT).show(); return }
        val list = repo.invoices().filter { selected.contains(it.number) }
        shareFile(createMarginPdf(list), "PDF هوامش الربح")
    }

    private fun shareFile(file: File, title: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, title))
        } catch (e: Exception) { Toast.makeText(this, "تعذر إنشاء أو مشاركة PDF", Toast.LENGTH_LONG).show() }
    }

    private fun createMarginPdf(invoices: List<Invoice>): File {
        val file = File(cacheDir, "mge_profit_${System.currentTimeMillis()}.pdf")
        val document = PdfDocument()
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 28f; color = Color.BLACK }
        var pageNo = 1
        var y = 60f
        var pdfPage = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
        fun newPage() { document.finishPage(pdfPage); pageNo++; pdfPage = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create()); y = 60f }
        fun line(text: String, size: Float = 24f, bold: Boolean = false) {
            paint.textSize = size; paint.typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, 515).setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(true).build()
            if (y + layout.height > 805) newPage()
            pdfPage.canvas.save(); pdfPage.canvas.translate(40f, y); layout.draw(pdfPage.canvas); pdfPage.canvas.restore(); y += layout.height + 9f
        }
        line("MGE-Profit — هامش الربح", 30f, true)
        line("تقرير تم إنشاؤه من بيانات الفواتير المحفوظة", 20f)
        invoices.forEach { inv ->
            line("فاتورة #${inv.number}", 27f, true)
            line("الزبون: ${inv.clientName.ifBlank { "-" }}    التاريخ: ${inv.date}")
            if (inv.commercial.isNotBlank()) line("Commercial: ${inv.commercial}    ربح الشريك: ${money(inv.commercialProfit)}")
            inv.items.forEach { item ->
                line("${item.name} | كمية ${fmtQty(item.quantity)} | بيع ${money(item.saleUnitPrice)} | شراء ${money(item.purchasePriceAtSale)} | هامش ${money(item.profitBeforeCommercial)}", 19f)
            }
            line("المبيعات: ${money(inv.productSales)}")
            line("تكلفة الشراء: ${money(inv.purchaseCost)}")
            line("هامش الربح قبل الشريك: ${money(inv.grossProfit)}")
            line("ربح الشريك: ${money(inv.commercialProfit)}")
            line("صافي ربح MGE: ${money(inv.netProfit)}", 25f, true)
            line("--------------------------------", 18f)
        }
        document.finishPage(pdfPage)
        file.outputStream().use { document.writeTo(it) }
        document.close()
        return file
    }
}
