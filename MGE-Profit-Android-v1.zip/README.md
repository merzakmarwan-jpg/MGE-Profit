# MGE-Profit Android

تطبيق Android مستقل لحساب أرباح فواتير MGE.

## المرحلة 1
- واجهة Android.
- اختيار ملف PDF من الهاتف.
- تجهيز GitHub Actions لبناء APK.
- التطبيق يعمل كبنية أولية، وسيتم في المراحل التالية إضافة استخراج بيانات PDF، المنتجات، أسعار الشراء، الفواتير، والتقارير.

## بناء APK
من GitHub:
Actions → Build MGE-Profit APK → Run workflow

بعد انتهاء البناء:
Artifacts → MGE-Profit-APK
