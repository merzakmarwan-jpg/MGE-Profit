package com.mge.profit

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.tvStatus)
        findViewById<Button>(R.id.btnImportPdf).setOnClickListener {
            openPdfPicker()
        }
    }

    private fun openPdfPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, PDF_REQUEST)
    }

    @Deprecated("Legacy activity result kept simple for the first build.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PDF_REQUEST || resultCode != Activity.RESULT_OK) return

        val uri: Uri = data?.data ?: return
        val name = uri.lastPathSegment ?: "PDF"
        status.text = "تم اختيار الملف: $name\n\nالمرحلة التالية ستقوم باستخراج بيانات الفاتورة تلقائياً."
        Toast.makeText(this, "تم اختيار الفاتورة", Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val PDF_REQUEST = 1001
    }
}
